"""Explicit isolated entry point for restored KHDN commands."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid

root=Path(__file__).resolve().parent
config=json.loads((root/'runtime.json').read_text())
manifest=json.loads((root/'snapshot.json').read_text())
source=Path(config['source'])
overlay=Path(config['overlay'])


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


for name,expected in manifest['files'].items():
    path=source/name
    actual='symlink:'+os.readlink(path) if path.is_symlink() else sha(path)
    if actual!=expected:
        raise RuntimeError('Restored source changed: '+name)
if sha(overlay/'triton/_C/libtriton.so')!=config['compiler_sha256']:
    raise RuntimeError('Restored compiler library changed')
if 'CUDA_VISIBLE_DEVICES' not in os.environ:
    raise SystemExit('Set CUDA_VISIBLE_DEVICES explicitly; use an empty value for CPU-only commands.')
cuda=os.environ['CUDA_VISIBLE_DEVICES']
if not re.fullmatch(r'[-A-Za-z0-9_,]*',cuda):
    raise SystemExit('Invalid CUDA_VISIBLE_DEVICES selector')
run=os.environ.get('KHDN_RUN_ID') or uuid.uuid4().hex
if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',run):
    raise SystemExit('KHDN_RUN_ID must contain1..64 letters, digits, underscores or hyphens')
environment=os.environ.copy()
environment.update(PYTHONPATH=str(overlay)+os.pathsep+str(root/'dependencies')+os.pathsep+str(source),PYTHONSAFEPATH='1',
                   PYTHONDONTWRITEBYTECODE='1',FLA_SOURCE_MANIFEST=str(root/'snapshot.json'),
                   KHDN_RESTORED_ROOT=str(root),KHDN_RUN_ID=run)
cache=root/'cache'/config['node_identity']/(cuda or 'cpu')/run
for key,folder in {'TRITON_CACHE_DIR':'triton','CUDA_CACHE_PATH':'cuda','TILELANG_CACHE_DIR':'tilelang',
                   'TILELANG_TMP_DIR':'tilelang-tmp','TORCHINDUCTOR_CACHE_DIR':'inductor',
                   'TORCH_EXTENSIONS_DIR':'extensions','XDG_CACHE_HOME':'xdg','TMPDIR':'tmp'}.items():
    path=cache/folder;path.mkdir(parents=True,exist_ok=True);environment[key]=str(path)
os.chdir(source)
os.execve(config['python'],[config['python'],'-P',*sys.argv[1:]],environment)
