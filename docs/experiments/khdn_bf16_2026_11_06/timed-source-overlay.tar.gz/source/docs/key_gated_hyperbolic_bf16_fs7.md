# Experimental seven-limb serial KHDN projection

Pass `precision_policy='bf16_fs7'` to the chunk operator or the chunk-mode layer/model config.
An omitted or legacy config still selects strict. Short no-grad decode still uses the strict recurrent entry.
The forward and adjoint eligibility limits and fallback paths are those of
[the short FS6 policy](key_gated_hyperbolic_bf16_fs6.md), including no carry, C16,
K=V128, group size 32 and at most 2048 tokens per document. The policy does not select a parallel backward.

Only F@S changes. Seven radix-256 digits retain 28 diagonal terms. Each digit dot
starts at FP32 zero and widens to FP64 before reconstruction. For K=128,
the absolute integer sum of a digit dot is at most 2²³; seven such integer
terms fit exactly in FP64. Normalizing by a non-power-of-two maximum, omitting
higher diagonals and rounding the weighted reconstruction can still disagree
with the strict ordered FP64 dot. Backward consumes the actual FP64 SavedS/SavedY;
the two backward kernels use strict arithmetic. A strict replay clears both radix flags.

The named implementation requires its own source binding, `BF16_FS7=True` only
in state forward, 28 BF16×BF16→FP32 dots and native BF16 MMA. FS6 retains
`BF16_FS6=True` and its 21-dot check. Neither policy accepts the other's
compiled arithmetic. Results from an isolated prototype using the FS6 host
selector do not attest this source or binary. This is not a training, timing
or distributed acceptance claim.
