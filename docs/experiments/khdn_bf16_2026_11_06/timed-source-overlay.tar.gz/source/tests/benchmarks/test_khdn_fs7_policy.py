# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
# SPDX-License-Identifier: MIT

"""CPU dispatch/trace controls. No claim that a fixture compiled or executed a GPU kernel."""
import ast
import math
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch
from test_khdn_bf16_fs6_harness import fs6_evidence, fs6_raw
from test_khdn_bf16_fs6_harness import source_modules as source_modules
from test_khdn_update_guard import native_boundary as native_boundary
from test_khdn_update_guard import run_guard

from benchmarks import hyperbolic_benchmark_utils as utils
from benchmarks.khdn_compiler_precision import compiled_precision_inventory


def fs7_record(modules, dots=28):
    binding = utils._khdn_radix_source_binding(*modules, 'bf16_fs7')
    calls = fs6_evidence(binding)
    row = calls[0]
    row['requested']['precision_policy'] = 'bf16_fs7'
    for opt in (row['executed_options'], row['backward_options']):
        opt.pop('bf16_fs6', None)
        opt['bf16_fs7'] = True
    row['telemetry'].update(precision_requested='bf16_fs7', precision_route='experimental_bf16_fs7',
                            backward_precision_route='experimental_bf16_fs7', arithmetic='bf16_fs7_projection')
    state = row['launches'][3]
    state['arguments'].update(BF16_FS7=True, BF16_FS6=False)
    state['selected_fs_callee'] = 'bf16_fs7'
    state['compiled_precision_inventory'] = compiled_precision_inventory(SimpleNamespace(asm=fs6_raw(dots)))
    return binding, calls


def attest(binding, calls):
    return utils.attest_khdn(calls, 16, 32, 'no_carry', precision_policy='bf16_fs7', source_binding=binding)


def test_named_radix_trace(request):
    modules = request.getfixturevalue('source_modules')
    binding, calls = fs7_record(modules)
    compact = utils._compact_khdn_assembly(attest(binding, calls))
    assert utils.reparse_khdn_trace(compact, expected_source_binding=binding)['backward_arithmetic'] == 'device_float64'
    with pytest.raises(AssertionError):
        utils.reparse_khdn_trace(compact, expected_source_binding=utils._khdn_fs6_source_binding(*modules))
    with pytest.raises(AssertionError, match='28'):
        attest(*fs7_record(modules, 21))


@pytest.mark.parametrize('attack', ['fs6_flag', 'fs6_option', 'missing_flag', 'wrong_helper', 'wrong_source', 'reverse_dot'])
def test_fs7_rejects_substitution(request, attack):
    modules = request.getfixturevalue('source_modules')
    binding, calls = fs7_record(modules)
    row = calls[0]
    state = row['launches'][3]
    if attack == 'fs6_flag':
        state['arguments']['BF16_FS6'] = True
    elif attack == 'fs6_option':
        row['executed_options']['bf16_fs6'] = True
    elif attack == 'missing_flag':
        del state['arguments']['BF16_FS7']
    elif attack == 'wrong_helper':
        state['selected_fs_callee'] = 'bf16_fs6'
    elif attack == 'wrong_source':
        binding['jit_functions']['state_fwd_kernel'] = '0' * 64
    else:
        row['launches'][4]['compiled_precision_inventory'] = state['compiled_precision_inventory']
    with pytest.raises(AssertionError):
        attest(binding, calls)


@pytest.mark.parametrize('attack', [None, 'bf16_fs6', 'skip_stage', 'stale_binding'])
def test_fs7_update_guard(request, attack):
    core = request.getfixturevalue('native_boundary')
    core.controller['baseline'] = 'bf16_fs7'
    if attack != 'stale_binding':
        core.binding = utils._khdn_radix_source_binding(core.chunk, core.kernels, 'bf16_fs7')
    if attack == 'bf16_fs6':
        core.controller['policy'] = attack
    elif attack == 'skip_stage':
        core.controller[attack] = 'state_bwd_kernel'
    if attack:
        with pytest.raises(AssertionError):
            run_guard(core)
    else:
        records, calls = run_guard(core)
        assert calls == ['step'] and records[0]['positive_observation']['original_graphs'] == 2
        assert all(o.get('bf16_fs7') and not o.get('bf16_fs6') for o in core.controller['options'])


def test_alias_and_replay_use_strict_options(request):
    chunk, _ = request.getfixturevalue('source_modules')
    # Isolate the real host replay/eligibility implementation; use a differentiable CPU VJP for the strict device call.
    functions = {'_strict_device_replay', '_source_alias_groups', '_mixed_adjoint_qualification', '_small_model_geometry'}
    tree = ast.parse(Path(chunk.__file__).read_text())
    nodes = [n for n in tree.body if getattr(n, 'name', '') in functions]
    seen = []

    def apply(q, k, v, beta, ell, state, c, options, details):
        seen.append((q is k, options.copy()))
        details.update(backward_precision='device_float64', source_gradient_aggregation='fp64_before_public_cast')
        return q + 2 * k, None

    scope = dict(torch=torch, math=math, _Chunk=SimpleNamespace(apply=apply))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), chunk.__file__, 'exec'), scope)
    x = torch.ones(1, 16, 1, 128)
    sources = (x, x, x.clone(), x[..., 0].clone(), x.clone(), x.new_zeros(1, 1, 128, 128), x.new_tensor(.6))
    groups = scope['_source_alias_groups'](sources)
    assert groups == ((0, 1),)
    opts = dict(mixed=False, bf16_fs7=True, c=16, g=32, carry='no_carry', bounds=[0, 16], source_alias_groups=groups)
    do = torch.full_like(x, 128)
    ds = torch.zeros_like(sources[5])
    eligibility = scope['_mixed_adjoint_qualification']
    assert eligibility(sources, opts, do, ds)[0] is None
    do = torch.nextafter(do, torch.full_like(do, float('inf')))
    assert eligibility(sources, opts, do, ds)[0] is not None
    telemetry = {}
    grads = scope['_strict_device_replay'](sources, opts, do, ds, [True, True] + [False] * 5, telemetry)
    assert seen == [(True, {k: v for k, v in opts.items() if k != 'bf16_fs7'})]
    assert torch.equal(grads[0], 3 * do) and all(x is None for x in grads[1:])
    assert telemetry['backward_precision_route'] == 'strict_device_replay' and opts['bf16_fs7']


@pytest.mark.parametrize('length,chunk,policy,selected', [
    (2048, 16, 'bf16_fs7', 'bf16_fs7'), (2049, 16, 'bf16_fs7', None), (16, 32, 'bf16_fs7', None),
    (16, 16, 'bf16_fs6', 'bf16_fs6'), (16, 16, 'strict', None), (16, 16, None, None),
])
def test_actual_host_selection_on_simulated_sm90(request, length, chunk, policy, selected):
    from test_khdn_update_guard import PretendCuda
    core = request.getfixturevalue('native_boundary')
    q = torch.zeros(1, length, 1, 128).as_subclass(PretendCuda)
    k = torch.zeros_like(q)
    k[..., 0] = 1.
    telemetry = {}
    kw = {} if policy is None else {'precision_policy': policy}
    core.package.chunk_key_gated_hyperbolic_delta_rule(q, k, q, torch.ones_like(q[..., 0]), -.1 + q,
                                                       scale=1., chunk_size=chunk, check_inputs=False, telemetry=telemetry, **kw)
    opts = core.controller['options'][-1]
    assert [p for p in ('bf16_fs6', 'bf16_fs7') if opts.get(p)] == ([selected] if selected else [])
    assert opts['mixed'] is False and telemetry['precision_requested'] == (policy or 'strict')
    if length > 2048 or chunk != 16:
        assert telemetry['qualification_reason'] in ('unqualified_geometry', 'unqualified_bf16_fs7_geometry')
        assert telemetry['precision_eligible'] is False
