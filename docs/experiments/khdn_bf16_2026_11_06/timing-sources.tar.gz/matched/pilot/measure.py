"""Bounded full24 W1 timing, with qualification/health checks outside timer windows.

Prepared only: release requires verified finite training and fresh-process recovery.
Each architecture runs in a fresh process, on the same card within its trial.
"""
from pathlib import Path
import collections
import functools
import gc
import gzip
import hashlib
import importlib
import json
import math
import os
import statistics
import sys
import time

D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
import timing_runtime as rt
from control_model import apply_full_output_projection,VARIANT

torch, b, h = rt.torch, rt.b, rt.h
O = rt.O
schedule = json.loads((D / 'timing-plan.json').read_bytes())
method = os.environ['TIMING_METHOD']
trial = int(os.environ['TIMING_TRIAL'])
assert method in ('kda', 'khdn_no_carry') and trial in (0, 1, 2)
assert schedule['status'] == 'RELEASED_AFTER_FINITE_AND_RECOVERY'
assert schedule['candidate_files'] == rt.plan['candidate_files']
assert collections.Counter(item['status'] for item in schedule['admission_receipts']) == {
    'FINITE_AND_REPLAY_SMALL_RECORDS_VERIFIED':3,
    'FULL_SAVED_CHECKPOINT_PAIRS_INDEPENDENTLY_VERIFIED':3,
    'CONTROL_FOUR_FINITE_UPDATES_COMPLETE':1,
    'MATCHED_OUTPUT_KDA_CHECKPOINT_BYTES_AND_REPLAY_VERIFIED':1,
}
args = b.parse_arguments(rt.plan['arguments'])
args.seed, args.data_seed = 101, 1009
args.methods = [method]
args.task_timeout = 7200
assert args.batch == 8 and args.seq_len == 2048 and args.scaling == 'single' and args.accumulation == 1
assert not args.no_layer_checkpoint and not args.no_short_conv and args.dtype == 'bf16'
assert args.loss_backend == 'plain' and not args.memory_only
assert schedule['warmup'] == 10 and schedule['samples'] == 30
assert schedule['model_seed'] == args.seed and schedule['data_seed'] == args.data_seed


def write(path, value):
    temporary = path.with_suffix('.partial')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    temporary.replace(path)


def stats(values):
    assert len(values) == 30 and all(math.isfinite(x) for x in values)
    return dict(median=statistics.median(values), p95=sorted(values)[28], minimum=min(values),
                maximum=max(values), stdev=statistics.stdev(values))


def timed_operation(*values, check_inputs=True, precision_policy='strict', telemetry=None, **kwargs):
    # Private explicit binding: preserve all candidate domain/nonfinite/native precision guards.
    assert precision_policy == 'strict' and kwargs['group_size'] == 32 and kwargs['chunk_size'] == 16
    assert kwargs['carry_mode'] == 'no_carry' and telemetry is None
    return rt.candidate.chunk(*values, arithmetic='bf16', telemetry=None, **kwargs)


def qualify(model, optimizer):
    batch = h.make_batch(args, 0).to('cuda')
    rng = h.capture_rng()
    hooks, kda_calls = [], []
    kmod = original_kda = None
    gates, route = {}, {}
    before = rt.weight_digest(model)
    started = time.perf_counter()
    try:
        if method == 'khdn_no_carry':
            rt.pkg.chunk_key_gated_hyperbolic_delta_rule = rt.operation
            rt.candidate.launch = rt.capture
            rt.reset_observations('three_product')
            hooks = rt.attach(model, 'three_product')
            rt.Autotuner._bench = rt.refuse_tuning
        else:
            rt.Autotuner._bench = rt.refuse_tuning
            kmod = importlib.import_module('fla.ops.kda.backends.tilelang.chunk_bwd_dqkg')
            original_kda = kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang

            @functools.wraps(original_kda)
            def observed(*values, **kwargs):
                q = kwargs['q'] if 'q' in kwargs else values[0]
                assert list(q.shape) == [8,2048,16,128]
                result = original_kda(*values, **kwargs)
                kda_calls.append(1)
                return result

            kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang = observed
        optimizer.zero_grad(set_to_none=True)
        with rt.NoFP64(), h.observe_key_gates(model, method) as gates:
            with b.autocast(args):
                output = model(**batch.inputs, use_cache=False, num_items_in_batch=batch.valid_labels)
            loss = output.loss
            assert torch.isfinite(loss)
            loss.backward()
            torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        gradient_norm = b.gradient_health(model)
        b.parameter_health(model)
        if method == 'khdn_no_carry':
            route = rt.attest(True)
            assert len(gates) == 24 and all(g['gate_projection_trainable'] and g['curvature'] == 1. and
                                           g['log_decay_min'] < g['log_decay_max'] < 0 for g in gates.values())
            assert before == schedule['khdn_initial_weights_sha256']
            rt.save_images()
        else:
            assert len(kda_calls) == 24
        assert before == rt.weight_digest(model) and not optimizer.state
        return dict(loss=float(loss.detach()), gradient_l2=gradient_norm, route=route, gates=gates,
                    kda_tilelang_backward_calls=len(kda_calls), untimed_wall_seconds=elapsed,
                    weights_unchanged=True, batch_sha256=batch.sha256)
    finally:
        for hook in hooks:
            hook.remove()
        if original_kda is not None:
            kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang = original_kda
        rt.candidate.launch = rt.original_launch
        rt.pkg.chunk_key_gated_hyperbolic_delta_rule = timed_operation
        rt.Autotuner._bench = rt.refuse_tuning
        optimizer.zero_grad(set_to_none=True)
        h.restore_rng(rng)


# Every runtime admission is a source-bound, actual completed receipt, not a planned status.
for item in schedule['admission_receipts']:
    path = Path(item['path'])
    assert rt.sha(path) == item['sha256']
    receipt = json.loads(path.read_bytes())
    assert receipt['status'] == item['status']

completed = []
with h.Runtime(args) as runtime, b.environment(b.method_spec(method)['environment']):
    assert runtime.rank == 0 and runtime.world_size == 1
    for mode in schedule['trials'][trial]['mode_order']:
        assert mode in ('fwd','bwd','fb','step')
        destination = O / mode
        destination.mkdir()
        gc.collect()
        torch.cuda.empty_cache()
        model, info = b.build_model(args, b.method_spec(method), small=False)
        if method == 'kda':
            assert rt.sha(D/'control_model.py') == schedule['control_sha256']
            binding = apply_full_output_projection(model,seed=args.seed)
            info.update(initial_weights_sha256=rt.weight_digest(model),parameter_count=binding['parameter_count'],configuration=model.config.to_dict())
            assert info['initial_weights_sha256'] == schedule['control_initial_weights_sha256']
        optimizer = h.make_optimizer(model, args)
        h.enforce_optimizer_policy(model, optimizer, .1)
        assert optimizer.defaults['betas'] == (.9,.95) and optimizer.defaults['eps'] == 1e-8
        assert optimizer.defaults['lr'] == .0001 and optimizer.defaults['fused'] is True
        assert info['parameter_dtype'] == 'torch.float32'
        assert info['parameter_count'] == schedule['expected_parameters'][method]
        attentions = [module for name,module in model.named_modules() if name in rt.plan['layer_names']]
        assert len(attentions) == 24
        for attention in attentions:
            projection = attention.g_proj
            if method == 'khdn_no_carry':
                assert isinstance(projection,torch.nn.Linear)
                assert (projection.in_features,projection.out_features) == (2048,2048) and projection.bias is None
            else:
                assert isinstance(projection,torch.nn.Linear)
                assert (projection.in_features,projection.out_features) == (2048,2048) and projection.bias is None
                assert model.config.benchmark_output_projection_variant == VARIANT
        del attentions,attention,projection
        if method == 'khdn_no_carry':
            assert info['parameter_count'] == 1412912512
            assert list(dict(model.named_parameters())) == rt.plan['names']
        else:
            assert json.loads(json.dumps(info['configuration'])) == schedule['kda_prior_configuration']
        qualification = qualify(model, optimizer)
        write(destination/'qualification.json', dict(model=info, **qualification))
        gc.collect()
        torch.cuda.empty_cache()
        tuners = {str(p.relative_to(rt.cache)):rt.sha(p) for p in rt.cache.rglob('*.autotune.json')}
        assert all(tuners.get(k) == v for k,v in rt.want.items())
        baseline = dict(allocated=torch.cuda.memory_allocated(), reserved=torch.cuda.memory_reserved())
        rows = []
        for i in range(40):
            batch = h.make_batch(args, i).to('cuda')
            assert list(batch.inputs['input_ids'].shape) == [8,2048] and batch.valid_labels == 16376
            # Pinned production timer: fresh graph, synchronization, clipping and Adam included for step.
            # Data transfer, zero_grad, health checks, source/metadata checks and JSON writes are outside.
            row = h.timed_sample(model, optimizer, [batch], args, runtime, mode)
            assert math.isfinite(row['loss']) and row['wall_ms'] > 0
            row.update(index=i, phase='warmup' if i < 10 else 'sample', batch_sha256=batch.sha256,
                       input_slots=16384, valid_labels=batch.valid_labels, nonpadding=batch.nonpadding_tokens)
            rows.append(row)
            write(destination/'samples.json', rows)
            del batch
        count = 40 if mode == 'step' else 0
        assert (not optimizer.state if count == 0 else
                len(optimizer.state) == len(list(model.parameters())) and
                all(int(state['step']) == count for state in optimizer.state.values()))
        assert {str(p.relative_to(rt.cache)):rt.sha(p) for p in rt.cache.rglob('*.autotune.json')} == tuners
        samples = rows[10:]
        result = dict(mode=mode, physical_optimizer_steps=count, wall_ms=stats([r['wall_ms'] for r in samples]),
                      cuda_ms=stats([r['cuda_ms'] for r in samples]), baseline_bytes=baseline,
                      memory_bytes={k:stats([r['training_memory'][k] for r in samples])
                                    for k in ('peak_allocated_bytes','peak_reserved_bytes')},
                      input_slots_per_second=stats([16384/(r['wall_ms']/1000) for r in samples]),
                      valid_labels_per_second=stats([16376/(r['wall_ms']/1000) for r in samples]),
                      tuner_sha256=tuners, parameters=info['parameter_count'])
        write(destination/'summary.json', result)
        completed.append(result)
        del model, optimizer, rows, samples
        gc.collect()
        torch.cuda.empty_cache()
write(O/'result.json', dict(status='FULL_W1_TIMING_COMPLETE', method=method, trial=trial, modes=completed,
    comparison_kind=schedule['comparison_kind'],output_projection=schedule['output_projection'][method],
    model_variant=VARIANT if method == 'kda' else 'canonical_KHDN_three_product',
    scope='One full24 B8T2048 BF16 W1 architecture/trial. Experimental uniform-three KHDN binding preserves '
          'candidate guards. No strict oracle or diagnostic observer in timers. No scaling or long-term quality claim.'))
