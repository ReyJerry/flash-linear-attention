"""Pinned runtime and actual kernel observations shared by finite training and fresh-process replay."""
from pathlib import Path
import collections
import contextlib
import gc
import gzip
import hashlib
import importlib
import json
import os
import sys
import tarfile
import traceback

D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
O = Path(os.environ['BF16_PROBE_OUT'])
plan = json.loads((D / 'model-plan.json').read_bytes())
pair = plan['seed_pairs'][int(os.environ['BF16_PROBE_SHARD'])]


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    path = O / name
    temporary = path.with_suffix('.partial')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    temporary.replace(path)


assert not any(name in sys.modules for name in ('torch','triton','fla','benchmarks'))
assert sha(D / 'performance-priority-addendum.json') == plan['addendum_sha256']
assert sha(D / 'acceptance-contract.txt') == plan['contract_sha256']
cache = Path(os.environ['TRITON_CACHE_DIR'])
assert not list(cache.iterdir())
reference_cache = Path(plan['cache_ref'])
index = reference_cache / 'cache.json'
assert sha(index) == plan['cache_manifest_sha256']
want = {n: h for n, h in json.loads(index.read_bytes()).items() if n.endswith('.autotune.json')}
assert len(want) == 10
seen = set()
with tarfile.open(reference_cache / 'triton-cache.tar.gz', 'r|gz') as archive:
    for member in archive:
        path = Path(member.name)
        name = str(path.relative_to('triton')) if path.is_relative_to('triton') else ''
        if name not in want:
            continue
        assert member.isfile() and name not in seen and len(Path(name).parts) == 2 and '..' not in Path(name).parts
        value = archive.extractfile(member).read()
        assert hashlib.sha256(value).hexdigest() == want[name]
        dest = cache / name
        dest.parent.mkdir(exist_ok=True)
        dest.write_bytes(value)
        seen.add(name)
assert seen == set(want)
write('preimport.json', dict(shared_tuners=want, compiled_cache_copied=False))

if os.environ['TIMING_METHOD']=='kda':
    control_path=Path(plan['control_train_result'])
    assert sha(control_path)==plan['control_train_result_sha256']
    control=json.loads(control_path.read_bytes())
    assert control['status']=='CONTROL_FOUR_FINITE_UPDATES_COMPLETE'
    tuner_archive=control_path.parent/'tuners.tar.gz'
    assert sha(tuner_archive)==control['tuners']['archive_sha256']
    control_want=control['tuners']['files'];control_seen=set()
    with tarfile.open(tuner_archive,'r|gz') as stream:
        for item in stream:
            assert item.isfile() and item.name in control_want and len(Path(item.name).parts)==2 and '..' not in Path(item.name).parts
            assert item.name not in control_seen;control_seen.add(item.name)
            value=stream.extractfile(item).read();assert hashlib.sha256(value).hexdigest()==control_want[item.name]
            dest=cache/item.name;dest.parent.mkdir(exist_ok=True)
            if dest.exists():assert sha(dest)==control_want[item.name]
            dest.write_bytes(value)
    assert control_seen==set(control_want)
    want=control_want
    write('preimport.json',dict(shared_tuners=want,compiled_cache_copied=False,control_tuners_frozen=True))

import torch
import triton
from torch.nn import functional as F
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_leaves
from triton.runtime.autotuner import Autotuner
from triton._C import libtriton
from benchmarks import benchmark_hyperbolic_training as b, hyperbolic_training_distributed as h
from benchmarks.hyperbolic_benchmark_utils import validated_source_snapshot
import operator_direct as candidate

torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32 = False
assert torch.__version__ == '2.9.0+cu128' and triton.__version__ == '3.5.0'
assert sha(libtriton.__file__) == plan['compiler']
root = Path(os.environ['KHDN_RESTORED_ROOT'])
assert validated_source_snapshot(root / 'source', root / 'snapshot.json')['snapshot_sha256'] == plan['named_snapshot']
assert torch.cuda.device_count() == 1 and not torch.distributed.is_initialized()
assert str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == os.environ['CUDA_VISIBLE_DEVICES'].removeprefix('GPU-')
for name, digest in plan['candidate_files'].items():
    assert sha(D / name) == digest


def refuse_tuning(*args, **kwargs):
    raise RuntimeError('Only frozen shared-kernel tuning choices are allowed')


original_autotuner_bench = Autotuner._bench
Autotuner._bench = refuse_tuning


class NoFP64(TorchDispatchMode):
    def __torch_dispatch__(self, fn, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        assert not any(isinstance(x, torch.Tensor) and x.dtype == torch.float64 for x in tree_leaves((args, kwargs)))
        value = fn(*args, **kwargs)
        assert not any(isinstance(x, torch.Tensor) and x.dtype == torch.float64 for x in tree_leaves(value))
        return value


def weight_digest(model):
    digest = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        cpu = value.detach().contiguous().cpu()
        digest.update(f'{name}:{tuple(cpu.shape)}:{cpu.dtype}'.encode())
        digest.update(memoryview(cpu.numpy()).cast('B'))
    return digest.hexdigest()


pkg = importlib.import_module('fla.ops.key_gated_hyperbolic_delta_rule')
strict = pkg.chunk_key_gated_hyperbolic_delta_rule
original_launch = candidate.launch
arm, current_layer = '', None
calls, launches, images = [], collections.Counter(), {}


def observe_layer(name):
    def hook(*_):
        global current_layer
        current_layer = name
    return hook


def operation(*args, check_inputs=True, precision_policy='strict', telemetry=None, **kwargs):
    assert precision_policy == 'strict' and kwargs['group_size'] == 32 and kwargs['chunk_size'] == 16
    assert kwargs['carry_mode'] == 'no_carry'
    q = args[0] if args else kwargs['q']
    assert list(q.shape) == [8,2048,16,128] and current_layer in plan['layer_names']
    calls.append(current_layer)
    if arm == 'strict_reference':
        info = {}
        output = strict(*args, check_inputs=check_inputs, precision_policy='strict', telemetry=info, **kwargs)
        assert info['backend'] == 'triton_chunk' and info['fallback_subblocks'] == 0
        return output
    return candidate.chunk(*args, arithmetic='bf16', telemetry=None, **kwargs)


def capture(kernel, grid, args, telemetry, **kwargs):
    compiled = original_launch(kernel, grid, args, telemetry, **kwargs)
    key = hashlib.sha256(compiled.asm['cubin']).hexdigest()
    images.setdefault(key, dict(name=kernel.__name__, ttir=compiled.asm['ttir'], ptx=compiled.asm['ptx']))
    launches[kernel.__name__] += 1
    return compiled



args = b.parse_arguments(plan['arguments'])
args.seed, args.data_seed = pair['model'], pair['data']
os.environ.update(b.method_spec('khdn_no_carry')['environment'])
assert args.lr == .0001 and args.weight_decay == .1 and args.clip_grad == 1.
assert not args.learnable_curvature and args.curvature == 1. and args.scaling == 'single' and args.accumulation == 1
pkg.chunk_key_gated_hyperbolic_delta_rule = operation
candidate.launch = capture

def reset_observations(role):
    global arm, current_layer, calls, launches
    arm, current_layer, calls, launches = role, None, [], collections.Counter()

def attest(backward):
    expected = 2 if backward else 1
    assert collections.Counter(calls) == {name: expected for name in plan['layer_names']}
    if arm == 'three_product':
        want = {n: 24*expected for n in ('common_fwd_kernel','group_fwd_kernel','group_af_fwd_kernel','state_fwd_kernel')}
        if backward: want.update({n:24 for n in ('state_bwd_kernel','common_bwd_kernel')})
        assert launches == want
    return dict(layer_calls=dict(collections.Counter(calls)), kernel_calls=dict(launches))

def attach(model, role):
    hooks = []
    for name, layer in model.named_modules():
        if name in plan['layer_names']:
            inner = observe_layer(name)
            def check(*values, inner=inner, role=role):
                assert arm == role
                return inner(*values)
            hooks.append(layer.register_forward_pre_hook(check))
    assert len(hooks) == 24
    return hooks

def candidate_guard(role):
    return NoFP64() if role == 'three_product' else contextlib.nullcontext()

def save_images():
    with gzip.open(O/'candidate-images.json.gz','wt') as stream: json.dump(images,stream)
