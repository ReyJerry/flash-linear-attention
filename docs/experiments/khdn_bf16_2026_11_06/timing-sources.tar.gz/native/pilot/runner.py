"""One dedicated card, two sequential fresh architecture processes, owned-child cleanup."""
from pathlib import Path
import json
import os
import signal
import subprocess
import sys

D = Path(__file__).resolve().parent
O = Path(os.environ['BF16_PROBE_OUT'])
plan = json.loads((D/'timing-plan.json').read_bytes())
trial = int(os.environ['TIMING_TRIAL'])
assert trial == 0 and plan['status'] == 'RELEASED_AFTER_FINITE_AND_RECOVERY'
records = []
child = None


def interrupted(sig, frame):
    raise RuntimeError('owned timing runner interrupted: '+str(sig))


signal.signal(signal.SIGTERM,interrupted)
signal.signal(signal.SIGINT,interrupted)
try:
    for method in plan['trials'][trial]['method_order']:
        destination = O/method
        destination.mkdir()
        env = dict(os.environ,BF16_PROBE_OUT=str(destination),TIMING_METHOD=method,
                   KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+method)
        command = [sys.executable,'-I',str(Path(os.environ['KHDN_RESTORED_ROOT'])/'run_project.py'),
                   '-B',str(D/'measure.py')]
        with (destination/'process.log').open('w') as log:
            child = subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=False)
            record = dict(method=method,pid=child.pid,
                birth=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19],command=command)
            records.append(record)
            (O/'children.json').write_text(json.dumps(records,indent=2))
            try:
                record['exit'] = child.wait(timeout=7300)
            finally:
                if child.poll() is None:
                    child.terminate()
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
                record.update(exit=child.returncode,reaped=child.poll() is not None)
                (O/'children.json').write_text(json.dumps(records,indent=2))
            assert record['exit'] == 0,method+' failed'
        result = json.loads((destination/'result.json').read_bytes())
        assert result['status'] == 'FULL_W1_TIMING_COMPLETE' and result['trial'] == trial
    (O/'result.json').write_text(json.dumps(dict(status='SAME_CARD_NATIVE_PAIR_TIMING_COMPLETE',
        trial=trial,children=records,comparison_kind=plan['comparison_kind'],
        scope='First independent trial only; two more trials and projection-matched control remain pending.'),indent=2))
finally:
    if child is not None and child.poll() is None:
        child.terminate()
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
