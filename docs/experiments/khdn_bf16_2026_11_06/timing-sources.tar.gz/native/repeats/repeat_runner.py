from pathlib import Path
import os,sys,json,hashlib,signal,subprocess
D=Path(__file__).resolve().parent;O=Path(os.environ['BF16_PROBE_OUT']);plan=json.loads((D/'timing-plan.json').read_bytes())
assert hashlib.sha256((D/'pilot-main-verified.json').read_bytes()).hexdigest()==plan['pilot_main_sha256']
assert json.loads((D/'pilot-main-verified.json').read_bytes())['status']=='FIRST_NATIVE_SAME_CARD_FULL_TIMING_MAIN_VERIFIED'
child=None;records=[]
def interrupted(sig,frame):raise RuntimeError('owned repeat sequence interrupted: '+str(sig))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 for trial in (1,2):
  dest=O/('trial'+str(trial));dest.mkdir();env=dict(os.environ,TIMING_TRIAL=str(trial),BF16_PROBE_OUT=str(dest),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-t'+str(trial))
  command=[sys.executable,'-I',str(Path(os.environ['KHDN_RESTORED_ROOT'])/'run_project.py'),'-B',str(D/'runner.py')]
  with (dest/'process.log').open('w') as log:
   child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=False)
   row=dict(trial=trial,pid=child.pid,birth=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19],command=command);records.append(row);(O/'children.json').write_text(json.dumps(records,indent=2))
   try:row['exit']=child.wait(timeout=14800)
   finally:
    if child.poll() is None:
     child.terminate()
     try:child.wait(timeout=5)
     except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
    row.update(exit=child.returncode,reaped=child.poll() is not None);(O/'children.json').write_text(json.dumps(records,indent=2))
   assert row['exit']==0,'repeat failed'
  result=json.loads((dest/'result.json').read_bytes());assert result['status']=='SAME_CARD_NATIVE_PAIR_TIMING_COMPLETE' and result['trial']==trial
 (O/'result.json').write_text(json.dumps(dict(status='TWO_ORDER_VARIED_NATIVE_REPEATS_COMPLETE',children=records),indent=2))
finally:
 if child is not None and child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
