"""Public entry paired operator timing after separated gauge backward; no model/optimizer throughput claim."""
from pathlib import Path
import gc,gzip,hashlib,importlib.util,json,math,os,statistics,subprocess,sys,time,xml.etree.ElementTree as ET
import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_leaves
from fla.ops.key_gated_hyperbolic_delta_rule import chunk_key_gated_hyperbolic_delta_rule as public
from fla.ops.key_gated_hyperbolic_delta_rule import bf16 as candidate
D=Path(__file__).resolve().parent;O=Path(os.environ['BF16_PROBE_OUT']);torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,x):(O/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
report=json.loads((D/'measurement-review.json').read_bytes())
for n,h in report['files'].items():assert sha(D/n)==h
root=Path(os.environ['KHDN_RESTORED_ROOT']);assert json.loads((root/'snapshot.json').read_bytes())['snapshot_sha256']=='6e52bfdb91f6de6ca2683cd0bb34011cd338002fcbdf789d5d4b07670c7749ae'
gate=Path('/mnt/cephfs/akseli/hyperbolic-validation/khdn-affine-mass-gate-6e52bfdb91f6');suite=ET.parse(gate/'gpu.xml').getroot().find('testsuite')
assert suite.attrib['tests']=='213' and all(suite.attrib[k]=='0' for k in ('errors','failures','skipped'))
assert json.loads((gate/'gpu-supervisor.json').read_bytes())['group_drained']
sanitizer=Path('/mnt/cephfs/akseli/hyperbolic-validation/khdn-affine-mass-sanitizer-ac3b7e5ad357')
assert json.loads((sanitizer/'result.json').read_bytes())['status']=='COMMON_SPLIT_SANITIZERS_COMPLETE'
for tool in ['memcheck','racecheck','synccheck']:
 sup=json.loads((sanitizer/tool/'supervisor.json').read_bytes());assert sup['exit']==0 and sup['group_drained']

assert torch.cuda.device_count()==1 and str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-')==os.environ['CUDA_VISIBLE_DEVICES'].removeprefix('GPU-')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
basekernels=load('split_baseline_kernels',D/'baseline/bf16_kernels.py');baseline=load('split_baseline_operator',D/'baseline/bf16.py');baseline.kernels=basekernels
candidate_function=candidate.chunk_bf16
arms=('baseline','split')
functions={'baseline':baseline.chunk_bf16,'split':candidate_function};modules={'baseline':baseline,'split':candidate}
class NoFP64(TorchDispatchMode):
 def __torch_dispatch__(self,fn,types,args=(),kwargs=None):
  kwargs=kwargs or {};assert not any(isinstance(x,torch.Tensor) and x.dtype==torch.float64 for x in tree_leaves((args,kwargs)))
  out=fn(*args,**kwargs);assert not any(isinstance(x,torch.Tensor) and x.dtype==torch.float64 for x in tree_leaves(out));return out
capture=Path('/mnt/cephfs/akseli/hyperbolic-validation/khdn-full-recapture-025bd0466bab/capture/strict-boundaries.pt')
assert sha(capture)=='6ddf7b66aa401a6f14e565dc6b28600d981bb74fea8859603367b619ce1dd1e3'
payload=torch.load(capture,weights_only=True,map_location='cpu',mmap=True);t=payload['tensors'];names=['q','k','v','beta','ell','state','curvature']
original_sources=[t['core.'+n].cuda() for n in names];do=t['core.do'].cuda();assert payload['needs']==[True]*5+[False]*2
assert list(do.shape)==[8,2048,16,128]
def metrics(actual,expected,back=False):
 a=actual.detach().cpu().reshape(-1);b=expected.detach().cpu().reshape(-1);assert a.shape==b.shape
 atol,rtol,ratio=(.005,.03,.015) if back else (.002,.02,.01);e2=r2=maximum=0.;bad=nonbitwise=0
 for x,y in zip(a.split(262144),b.split(262144)):
  assert torch.isfinite(x).all() and torch.isfinite(y).all();u,v=x.double(),y.double();delta=u-v
  e2+=float(delta.square().sum());r2+=float(v.square().sum());maximum=max(maximum,float(delta.abs().max()))
  bad+=int((delta.abs()>atol+rtol*v.abs()).sum());nonbitwise+=int((x.view(torch.int32)!=y.view(torch.int32)).sum())
 rms=(e2/a.numel())**.5;ref=(r2/a.numel())**.5
 return dict(max_abs=maximum,error_rms=rms,reference_rms=ref,bad=bad,nonbitwise=nonbitwise,passed=bad==0 and rms<=ratio*max(ref,atol))
def invoke(xs,cu):return public(*xs[:5],curvature=xs[6],initial_state=xs[5],scale=1.,group_size=32,chunk_size=16,carry_mode='no_carry',precision_policy='bf16',cu_seqlens=cu)[0]
rows=[];qualifications={};inventory={};images={}
for layout in ('dense','packed'):
 cu=None;sources=original_sources;incoming=do
 if layout=='packed':
  sources=[x.reshape(1,-1,*x.shape[2:]) for x in original_sources[:5]]+original_sources[5:]
  cu=torch.tensor([0,0,2039,4096,6137,8192,10243,12288,14329,16384],device='cuda',dtype=torch.int64)
  sources[5]=torch.zeros(9,16,128,128,device='cuda');incoming=do.reshape(1,16384,16,128)
 xs=[x.detach().requires_grad_(i<5) for i,x in enumerate(sources)];base_values={}
 for arm in arms:
  candidate.chunk_bf16=functions[arm];module=modules[arm];old_launch=module.launch;calls=[];resource={}
  def capture_launch(kernel,grid,args,telemetry,**kwargs):
   obj=old_launch(kernel,grid,args,telemetry,**kwargs);calls.append(kernel.__name__);key=hashlib.sha256(obj.asm['cubin']).hexdigest()
   images[key]=dict(name=kernel.__name__,ttir=obj.asm['ttir'],ptx=obj.asm['ptx'])
   resource[kernel.__name__]=dict(n_regs=getattr(obj,'n_regs',None),n_spills_reported=getattr(obj,'n_spills',None),shared=obj.metadata.shared,num_warps=obj.metadata.num_warps,cubin=key)
   return obj
  module.launch=capture_launch
  try:
   with NoFP64():
    y=invoke(xs,cu);grads=torch.autograd.grad(y,xs[:5],incoming)
   values=dict(output=y,**dict(zip(names[:5],grads)))
   if arm=='baseline':base_values={n:v.detach().cpu().contiguous() for n,v in values.items()}
   comparison={n:metrics(v,base_values[n],n!='output') for n,v in values.items()}
   assert all(v['passed'] for v in comparison.values())
   reference=None
   if layout=='dense':
    truth=dict(output=t['core.output'],**{n:t['core.partial.'+n] for n in names[:5]})
    reference={n:metrics(v,truth[n],n!='output') for n,v in values.items()};assert all(v['passed'] for v in reference.values())
   expected=['common_base_fwd_kernel','common_interval_fwd_kernel','common_system_fwd_kernel','group_fwd_kernel','group_af_fwd_kernel','state_fwd_kernel','output_fwd_kernel','output_bwd_kernel','state_bwd_kernel','parameter_bwd_kernel','gauge_bwd_kernel']+['common_matrix_bwd_kernel','common_interval_bwd_kernel']
   assert calls==expected
   qualifications[layout+'/'+arm]=dict(comparison=comparison,strict_capture=reference,calls=calls)
   inventory[layout+'/'+arm]=resource
   del values,y,grads
  finally:module.launch=old_launch
 write('qualification.json',qualifications);write('inventory.json',inventory);gc.collect();torch.cuda.empty_cache()
 for mode in ('fwd','bwd','fb'):
  for i in range(40):
   order=arms if i%2==0 else arms[::-1]
   for arm in order:
    candidate.chunk_bf16=functions[arm];gc.collect()
    if mode=='bwd':y=invoke(xs,cu)
    torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();entry=torch.cuda.memory_allocated()
    begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True);begin.record();start=time.perf_counter()
    if mode!='bwd':y=invoke(xs,cu)
    if mode!='fwd':grads=torch.autograd.grad(y,xs[:5],incoming)
    end.record();torch.cuda.synchronize();wall=(time.perf_counter()-start)*1000
    rows.append(dict(layout=layout,mode=mode,arm=arm,index=i,phase='warmup' if i<10 else 'sample',wall_ms=wall,cuda_ms=begin.elapsed_time(end),peak_allocated=torch.cuda.max_memory_allocated(),peak_reserved=torch.cuda.max_memory_reserved(),entry_allocated=entry))
    del y
    if mode!='fwd':del grads
  write('samples.json',rows)
 del xs,base_values;gc.collect();torch.cuda.empty_cache()
with gzip.open(O/'images.json.gz','wt') as stream:json.dump(images,stream)
summary={}
for layout in ('dense','packed'):
 summary[layout]={}
 for mode in ('fwd','bwd','fb'):
  summary[layout][mode]={}
  for arm in arms:
   values=[r for r in rows if r['layout']==layout and r['mode']==mode and r['arm']==arm and r['phase']=='sample'];assert len(values)==30
   summary[layout][mode][arm]=dict(median_ms=statistics.median(r['wall_ms'] for r in values),p95_ms=sorted(r['wall_ms'] for r in values)[28],peak_allocated=max(r['peak_allocated'] for r in values),peak_reserved=max(r['peak_reserved'] for r in values))
write('result.json',dict(status='PUBLIC_OPERATOR_PAIRED_TIMING_COMPLETE',rows=len(rows),summary=summary,physical_optimizer_updates=0,
 scope='Actual public dispatcher+wrapper allocations/domain/finite/compiled guards/autograd; fresh graph per backward.10warm30steady,twoarmorderalternated,sameGPU. No external TorchDispatch diagnostics timed. Dense actualLayer0 sources/dO and retainedstricttruth; packed regrouping uses baseline parity only. Allocated includes live tensors; reserved is process cache scope, not isolated perarm. Not full-model or training-throughput acceptance.'))
print(json.dumps(summary));candidate.chunk_bf16=candidate_function
