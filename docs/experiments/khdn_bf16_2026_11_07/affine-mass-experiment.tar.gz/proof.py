"""Untimed algebra check for the existing local positive-mass affine recurrence."""
from pathlib import Path
import json
import torch

def scan(a,b):
    a,b=a.clone(),b.clone()
    offset=1
    while offset<a.numel():
        aa,bb=a.clone(),b.clone()
        aa[offset:]=a[offset:]*a[:-offset]
        bb[offset:]=b[offset:]+a[offset:]*b[:-offset]
        a,b=aa,bb;offset*=2
    return a,b

def sequential(beta,lam,n,w):
    previous=beta.new_tensor(1.);r=[];t=[];zp=[]
    for i in range(beta.numel()):
        zp.append(previous);rr=(1-beta[i])/lam[i]*previous;tt=n[i]*w[i]
        r.append(rr);t.append(tt);previous=rr+tt
    return torch.stack(r),torch.stack(t),torch.stack(zp)

def parallel(beta,lam,n,w):
    a=(1-beta)/lam;t=n*w
    aa,bb=scan(a,t);z=aa+bb;zp=torch.cat((z.new_ones(1),z[:-1]))
    return a*zp,t,zp

def reverse(beta,lam,n,w,zp,gr,gt):
    a=(1-beta)/lam
    _,back=scan(a.flip(0),(a*gr).flip(0))
    inclusive=back.flip(0);future=torch.cat((inclusive[1:],inclusive.new_zeros(1)))
    gri,gti=gr+future,gt+future
    return -zp/lam*gri,gti*w,gti*n

rows=[]
for length in [1,3,8,16]:
 for seed in range(8):
    gen=torch.Generator().manual_seed(1009+seed)
    beta=torch.rand(16,generator=gen,dtype=torch.float64);beta[0]=0.;beta[min(length-1,15)]=1.;beta[length:]=0.
    lam=.5+torch.rand(16,generator=gen,dtype=torch.float64)*1.5;lam[length:]=1.
    n=.1+torch.rand(16,generator=gen,dtype=torch.float64);w=torch.rand(16,generator=gen,dtype=torch.float64);w[length:]=0.
    beta.requires_grad_();n.requires_grad_();w.requires_grad_()
    gr=torch.randn(16,generator=gen,dtype=torch.float64);gt=torch.randn(16,generator=gen,dtype=torch.float64);gr[length:]=0.;gt[length:]=0.
    r,t,zp=sequential(beta,lam,n,w);rr,tt,zz=parallel(beta,lam,n,w)
    truth=torch.autograd.grad((r*gr+t*gt).sum(),(beta,n,w));actual=reverse(beta,lam,n,w,zz,gr,gt)
    f=max(float((a-b).detach().abs().max()) for a,b in zip((r,t,zp),(rr,tt,zz)))
    g=max(float((a-b).detach().abs().max()) for a,b in zip(truth,actual))
    assert f<1e-12 and g<1e-11
    rows.append(dict(length=length,seed=seed,forward_error=f,vjp_error=g))
result=dict(status='AFFINE_MASS_SCAN_ALGEBRA_32_CASES_PASS',cases=len(rows),max_forward_error=max(r['forward_error'] for r in rows),max_vjp_error=max(r['vjp_error'] for r in rows),scope='UntimedCPUFP64 algebra only. Fixed-gauge localmass recurrence andbeta/n/wVJP;beta0/1 andtailmaskincluded. No GPU/BF16/performance qualification; no source or mainrepo change. ProspectiveC16-only parallel scan could remove the per-token local loop without buffers orprecision increase.')
Path(__file__).with_name('proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
