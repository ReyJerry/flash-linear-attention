"""Recompute approved and legacy errors from every original saved operator tensor."""
from pathlib import Path
import collections
import gzip
import hashlib
import importlib.util
import json
import math
import os
import re
import torch

D = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins = json.loads((D / 'probe-contract.json').read_bytes())
assert sha(D / 'acceptance-contract.txt') == pins['acceptance_contract_sha256']
torch.set_num_threads(2)
cases = {x['name']: x for x in pins['cases']}
rows, failures, legacy_failed, images_count = [], collections.Counter(), 0, 0
special_checks = collections.Counter()
oracle_checks = []
truth_file = Path(os.environ['KHDN_RESTORED_ROOT'])/'source/fla/ops/key_gated_hyperbolic_delta_rule/naive.py'
spec = importlib.util.spec_from_file_location('independent_dense_truth', truth_file)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
truth = module.naive_recurrent_key_gated_hyperbolic_delta_rule
selected = {'bf16-no_carry-C16-seed1009', 'fp32-y_carry-C64-seed2003', 'cancellation-no_carry-6-seed1009', 'bf16-y_carry-C64-seed1009', 'fp32-no_carry-C64-seed1009', 'fp32-y_carry-C64-seed1009'}
for shard in range(3):
    folder = D / f'collected/raw/s{shard}'
    report = json.loads((folder / 'result.json').read_bytes())
    assert report['acceptance_contract_sha256'] == pins['acceptance_contract_sha256']
    assert report['physical_optimizer_updates'] == 0
    for row in report['cases']:
        case = row['case']
        assert cases.pop(case['name']) == case and case['shard'] == shard
        assert row['status'] in ('PASS', 'NUMERICAL_FAIL'), row
        path = folder / row['tensor_file']
        assert sha(path) == row['tensor_sha256']
        payload = torch.load(path, weights_only=True, map_location='cpu')
        assert len(payload['sources']) == len(payload['gradients']) == len(payload['reference_gradients']) == 7
        measured = []
        pairs = list(zip(('output', 'state'), payload['actual'], payload['reference'])) + list(zip(
            ('dq', 'dk', 'dv', 'dbeta', 'dell', 'dS0', 'dc'), payload['gradients'], payload['reference_gradients']))
        for index, (name, actual, expected) in enumerate(pairs):
            assert actual.dtype in (torch.float32, torch.bfloat16) and expected.dtype == torch.float64
            assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
            backward = index >= 2
            a, b = actual.double(), expected.double()
            error = (a - b).abs()
            rms = float(error.square().mean().sqrt()) if error.numel() else 0.
            ref_rms = float(b.square().mean().sqrt()) if b.numel() else 0.
            maximum = float(error.max()) if error.numel() else 0.
            atol, rtol, ratio = pins['gradient_budget'] if backward else pins['output_state_budget']
            bad = int((error > atol + rtol * b.abs()).sum())
            passed = bad == 0 and rms <= ratio * max(ref_rms, atol)
            recorded = row['metrics'][name]
            assert passed == recorded['passed'] and bad == recorded['approved_elementwise_bad']
            assert math.isclose(maximum, recorded['max_abs'], abs_tol=1e-14, rel_tol=1e-10)
            assert math.isclose(rms, recorded['rms'], abs_tol=1e-14, rel_tol=1e-10)
            if actual.dtype == torch.bfloat16:
                la, lr, ratio_old = (.005, .03, .015) if backward else (.002, .02, .01)
            else:
                la, lr, ratio_old = (5e-5, 5e-4, 2e-4) if backward else (2e-5, 2e-4, 1e-4)
            legacy = bool((error <= la + lr * b.abs()).all()) and rms <= ratio_old * max(ref_rms, la)
            assert legacy == recorded['legacy_passed']
            if not passed:
                failures[name] += 1
            measured.append(dict(name=name, passed=passed, legacy_passed=legacy, bad=bad,
                                 max_abs=maximum, rms=rms, limit=ratio * max(ref_rms, atol)))
        assert (row['status'] == 'PASS') == all(x['passed'] for x in measured)
        legacy_failed += not all(x['legacy_passed'] for x in measured)
        if case['length'] == 0:
            assert torch.equal(payload['actual'][1], payload['sources'][5])
            assert torch.equal(payload['gradients'][5], payload['cotangents'][1])
            assert all(not x.numel() or torch.count_nonzero(x) == 0 for i, x in enumerate(payload['gradients']) if i != 5)
            special_checks['exact_empty'] += 1
        if case.get('special') == 'strong-decay':
            target = torch.tensor(.5 * math.exp(-1))
            torch.testing.assert_close(payload['actual'][1][0,0,0,0], target, atol=2e-5, rtol=2e-5)
            torch.testing.assert_close(payload['gradients'][4][0,1,0,0], target, atol=2e-5, rtol=2e-5)
            special_checks['original_strong_decay'] += 1
        images = json.loads(gzip.decompress((folder / (case['name'] + '-images.json.gz')).read_bytes()))
        for image in images.values():
            assert not re.search(r'\bf64\b|xf64\b', image['ttir']) and not re.search(r'\.f64\b', image['ptx'])
            images_count += 1
        if case['name'] in selected:
            sources = tuple(x.detach().double().requires_grad_() for x in payload['sources'])
            expected = truth(*sources[:5], curvature=sources[6], initial_state=sources[5], output_final_state=True,
                             cu_seqlens=payload['cu'], group_size=16 if case.get('special') == 'readout-cancellation' else 32,
                             scale=1. if case.get('special') == 'readout-cancellation' else None)
            gradients = torch.autograd.grad(expected, sources, tuple(x.double() for x in payload['cotangents']))
            for a, b in zip((*expected, *gradients), (*payload['reference'], *payload['reference_gradients'])):
                torch.testing.assert_close(a, b, atol=1e-10, rtol=1e-8)
            oracle_checks.append(case['name'])
        rows.append(dict(name=case['name'], status=row['status'], metrics=measured))
assert not cases and len(rows) == 108 and set(oracle_checks) == selected
result = dict(status='APPROVED_CONTRACT_OPERATOR_GATE_FAILED' if failures else 'APPROVED_CONTRACT_OPERATOR_GATE_PASSED',
              cases=108, passed=sum(x['status'] == 'PASS' for x in rows), failed=sum(x['status'] != 'PASS' for x in rows),
              failed_case_counts_by_tensor=dict(failures), legacy_failed_cases=legacy_failed,
              semantic_checks=dict(special_checks), native_image_instances=images_count, fp64_candidate=False,
              independent_cpu_dense_rechecks=oracle_checks, oracle_sha256=sha(truth_file),
              contract_sha256=pins['acceptance_contract_sha256'], raw_rows=rows,
              full_model_updates_authorized_by_this_gate=not bool(failures))
(D / 'verified.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'raw_rows'}))
