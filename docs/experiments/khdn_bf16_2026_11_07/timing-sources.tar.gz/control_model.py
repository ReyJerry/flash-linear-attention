"""Explicit KDA ablation with KHDN's full output projection; never a native-KDA alias.

The attention recurrence, decay/beta projections, ShortConv, normalization, FFN,
depth and widths remain the native KDA implementation. Only g_proj is replaced.
This research variant must be constructed with this helper before checkpoint load.
"""
import torch

VARIANT = 'kda_full_output_projection_2048x2048_no_bias_v1'


def full_projection(seed, std, device):
    # nn.Linear's initial allocation consumes CPU RNG; restore it. The actual
    # weights use a private CPU generator and never reseed CUDA/global RNG.
    with torch.random.fork_rng(devices=[]):
        projection = torch.nn.Linear(2048,2048,bias=False,device='cpu',dtype=torch.float32)
    generator = torch.Generator(device='cpu').manual_seed(seed)
    torch.nn.init.normal_(projection.weight,mean=0.,std=std,generator=generator)
    projection._is_hf_initialized = True
    return projection.to(device=device,dtype=torch.float32)


def apply_full_output_projection(model, *, seed):
    config = model.config
    assert config.model_type == 'kda' and config.hidden_size == 2048 and config.num_hidden_layers == 24
    assert config.num_heads == 16 and config.head_dim == 128 and config.intermediate_size == 5184
    assert not hasattr(config,'benchmark_output_projection_variant'), 'refuse to apply the ablation twice'
    before = dict(model.named_parameters())
    native_count = sum(value.numel() for value in before.values())
    assert native_count == 1324881280
    unchanged = {name:value for name,value in before.items() if '.attn.g_proj.' not in name}
    attentions = [(name,module) for name,module in model.named_modules()
                  if name in {f'model.layers.{i}.attn' for i in range(24)}]
    assert [name for name,_ in attentions] == [f'model.layers.{i}.attn' for i in range(24)]
    cpu_rng = torch.get_rng_state().clone()
    for i,(name,attention) in enumerate(attentions):
        original = attention.g_proj
        assert isinstance(original,torch.nn.Sequential) and len(original) == 2
        assert (original[0].in_features,original[0].out_features) == (2048,128) and original[0].bias is None
        assert (original[1].in_features,original[1].out_features) == (128,2048) and original[1].bias is not None
        assert original[0].weight.dtype == original[1].weight.dtype == torch.float32
        replacement = full_projection(seed+1000003*(i+1),config.initializer_range,original[0].weight.device)
        replacement.train(attention.training)
        attention.g_proj = replacement
    assert torch.equal(cpu_rng,torch.get_rng_state())
    after = dict(model.named_parameters())
    assert all(after[name] is value for name,value in unchanged.items())
    count = sum(value.numel() for value in after.values())
    assert count == 1412912512 and len(after) == 459
    assert all(value.requires_grad and value.dtype == torch.float32 for value in after.values())
    config.benchmark_output_projection_variant = VARIANT
    config.benchmark_output_projection_seed = seed
    return dict(variant=VARIANT,native_parameter_count=native_count,parameter_count=count,
                parameter_tensors=len(after),extra_parameters=count-native_count,
                output_projection='Linear(2048,2048,bias=False)',
                initializer='Normal(0,config.initializer_range), private CPU seed+1000003*(layer+1)',
                norm='Native sigmoid-gated RMSNorm unchanged',
                scope='Explicit output-projection ablation; not native KDA or a replacement for its timings.')
