"""Same-card full24 timings through public KHDN and separately named KDA variants."""
from pathlib import Path
import functools,gc,gzip,importlib,json,math,os,statistics,sys
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
import timing_runtime as rt
from control_model import apply_full_output_projection,VARIANT
torch,b,h,O=rt.torch,rt.b,rt.h,rt.O
variant=os.environ['TIMING_VARIANT'];trial=int(os.environ['TIMING_TRIAL'])
assert variant in ('khdn','kda','kda_matched') and trial in (0,1,2)
method='khdn_no_carry' if variant=='khdn' else 'kda'
schedule=json.loads((D/'timing-plan.json').read_bytes())
assert schedule['status']=='RELEASED_AFTER_FINITE_AND_RECOVERY'
assert schedule['source']==rt.plan['named_snapshot']=='619f6549531d9e56738db626ac4ea8466d8cc472d56b989a0aee446baaf24788'
assert schedule['quality_policy_sha256']==rt.sha(D/'quality-policy.json')
assert {x['role'] for x in schedule['admission_receipts']}==set(schedule['required_receipt_roles'])
for item in schedule['admission_receipts']:
 p=Path(item['path']);assert rt.sha(p)==item['sha256']
 assert json.loads(p.read_bytes())['status']==item['status']
args=b.parse_arguments(rt.plan['arguments']);args.seed,args.data_seed=101,1009
args.methods=[method];args.task_timeout=7200;args.khdn_precision_policy='bf16'
assert (args.batch,args.seq_len,args.layers,args.heads,args.head_dim)==(8,2048,24,16,128)
assert args.hidden_size==2048 and args.intermediate_size==5184 and args.vocab_size==32000
assert args.scaling=='single' and args.accumulation==1 and args.dtype=='bf16'
assert not args.no_layer_checkpoint and not args.no_short_conv and not args.memory_only
assert args.loss_backend=='plain' and schedule['warmup']==10 and schedule['samples']==30

def write(path,value):
 tmp=path.with_suffix('.partial');tmp.write_text(json.dumps(value,indent=2,allow_nan=False));tmp.replace(path)

def stats(values):
 assert len(values)==30 and all(math.isfinite(x) for x in values)
 return dict(median=statistics.median(values),p95=sorted(values)[28],minimum=min(values),maximum=max(values),stdev=statistics.stdev(values))

def qualify(model,optimizer,destination):
 rng=h.capture_rng();batch=h.make_batch(args,0).to('cuda')
 before=rt.weight_digest(model);hooks=[];kmod=original_kda=None;kda_calls=[]
 try:
  if variant=='khdn':
   rt.pkg.chunk_key_gated_hyperbolic_delta_rule=rt.operation
   rt.candidate.launch=rt.capture;rt.reset_observations('candidate');hooks=rt.attach(model,'candidate')
  else:
   kmod=importlib.import_module('fla.ops.kda.backends.tilelang.chunk_bwd_dqkg')
   original_kda=kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang
   @functools.wraps(original_kda)
   def observed(*values,**kwargs):
    q=kwargs['q'] if 'q' in kwargs else values[0];assert list(q.shape)==[8,2048,16,128]
    value=original_kda(*values,**kwargs);kda_calls.append(1);return value
   kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang=observed
  optimizer.zero_grad(set_to_none=True)
  with rt.NoFP64(),h.observe_key_gates(model,method) as gates:
   loss=h.weighted_loss(model,batch,args,batch.valid_labels,1)
   assert torch.isfinite(loss);loss.backward();torch.cuda.synchronize()
  norms=b.gradient_health(model);b.parameter_health(model)
  route={}
  if variant=='khdn':
   route=rt.attest(True)
   assert len(gates)==24 and all(x['curvature']==1 and x['gate_projection_trainable'] and x['log_decay_min']<x['log_decay_max']<0 for x in gates.values())
   with gzip.open(destination/'images.json.gz','wt') as f:json.dump(rt.images,f)
  else:assert len(kda_calls)==24
  assert before==rt.weight_digest(model)==schedule['initial_weights_sha256'][variant] and not optimizer.state
  return dict(loss=float(loss.detach()),gradient_l2=norms,route=route,gates=gates,
              kda_tilelang_backward_calls=len(kda_calls),batch_sha256=batch.sha256,weights_unchanged=True)
 finally:
  for hook in hooks:hook.remove()
  if original_kda is not None:kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang=original_kda
  rt.candidate.launch=rt.original_launch
  rt.pkg.chunk_key_gated_hyperbolic_delta_rule=rt.strict
  optimizer.zero_grad(set_to_none=True);h.restore_rng(rng)

completed=[]
with h.Runtime(args) as runtime,b.environment(b.method_spec(method)['environment']):
 assert runtime.world_size==1 and runtime.rank==0
 for mode in schedule['trials'][trial]['mode_order']:
  assert mode in ('fwd','bwd','fb','step');dest=O/mode;dest.mkdir()
  gc.collect();torch.cuda.empty_cache()
  model,info=b.build_model(args,b.method_spec(method),small=False)
  binding=None
  if variant=='kda_matched':
   assert rt.sha(D/'control_model.py')==schedule['control_sha256']
   binding=apply_full_output_projection(model,seed=101)
   info.update(initial_weights_sha256=rt.weight_digest(model),parameter_count=binding['parameter_count'],configuration=model.config.to_dict())
  assert info['parameter_dtype']=='torch.float32' and info['parameter_count']==schedule['parameters'][variant]
  assert info['initial_weights_sha256']==schedule['initial_weights_sha256'][variant]
  if variant=='khdn':
   assert model.config.precision_policy=='bf16' and list(dict(model.named_parameters()))==rt.plan['names']
  else:
   assert json.loads(json.dumps(info['configuration']))==schedule['kda_configuration'][variant]
   assert len(list(model.parameters()))==(507 if variant=='kda' else 459)
  attentions=[m for n,m in model.named_modules() if n in rt.plan['layer_names']];assert len(attentions)==24
  for attention in attentions:
   projection=attention.g_proj
   if variant in ('khdn','kda_matched'):
    assert isinstance(projection,torch.nn.Linear) and (projection.in_features,projection.out_features)==(2048,2048) and projection.bias is None
   else:
    assert isinstance(projection,torch.nn.Sequential) and len(projection)==2
    assert (projection[0].in_features,projection[0].out_features)==(2048,128) and projection[0].bias is None
    assert (projection[1].in_features,projection[1].out_features)==(128,2048) and projection[1].bias is not None
  del attentions,attention,projection
  optimizer=h.make_optimizer(model,args);h.enforce_optimizer_policy(model,optimizer,.1)
  assert optimizer.defaults['betas']==(.9,.95) and optimizer.defaults['eps']==1e-8 and optimizer.defaults['lr']==.0001 and optimizer.defaults['fused']
  proof=qualify(model,optimizer,dest);write(dest/'qualification.json',dict(model=info,binding=binding,**proof))
  gc.collect();torch.cuda.empty_cache()
  tuners={str(p.relative_to(rt.cache)):rt.sha(p) for p in rt.cache.rglob('*.autotune.json')};assert tuners==rt.want
  baseline=dict(allocated=torch.cuda.memory_allocated(),reserved=torch.cuda.memory_reserved())
  physical=[0]
  def counted(*_):physical[0]+=1
  hook=optimizer.register_step_post_hook(counted);rows=[]
  for index in range(40):
   batch=h.make_batch(args,index).to('cuda');assert batch.valid_labels==16376 and batch.input_slots==16384
   row=h.timed_sample(model,optimizer,[batch],args,runtime,mode)
   row.update(index=index,phase='warmup' if index<10 else 'sample',batch_sha256=batch.sha256)
   rows.append(row);write(dest/'samples.json',rows);del batch
  hook.remove();expected=40 if mode=='step' else 0
  assert physical[0]==expected
  assert (not optimizer.state if expected==0 else len(optimizer.state)==len(list(model.parameters())) and all(int(s['step'])==40 for s in optimizer.state.values()))
  assert {str(p.relative_to(rt.cache)):rt.sha(p) for p in rt.cache.rglob('*.autotune.json')}==tuners
  steady=rows[10:]
  result=dict(mode=mode,physical_optimizer_steps=physical[0],parameters=info['parameter_count'],
              wall_ms=stats([x['wall_ms'] for x in steady]),cuda_ms=stats([x['cuda_ms'] for x in steady]),
              memory_bytes={k:stats([x['training_memory'][k] for x in steady]) for k in ['peak_allocated_bytes','peak_reserved_bytes']},
              input_slots_per_second=stats([16384/(x['wall_ms']/1000) for x in steady]),
              valid_labels_per_second=stats([16376/(x['wall_ms']/1000) for x in steady]),baseline_bytes=baseline,tuners=tuners)
  write(dest/'summary.json',result);completed.append(result)
  del model,optimizer,rows,steady;gc.collect();torch.cuda.empty_cache()
write(O/'result.json',dict(status='FINAL_PUBLIC_W1_ARM_TIMING_COMPLETE',variant=variant,trial=trial,modes=completed,
                          source=rt.plan['named_snapshot'],quality_policy_sha256=schedule['quality_policy_sha256'],
                          scope='Samefull24B8T2048;publicKHDN dispatch/wrapper checks remain timed. NativeKDA and separately namedmatchedprojection variant.10warm30steady per mode; actual40Adamupdates instep. No scaling orrealcorpusquality claim.'))
