"""Own a single Linux training process group. The worker is its sole waiter."""
import ctypes
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

STOP = (signal.SIGTERM, signal.SIGINT)
# The write end is never inherited. EOF is a refusal, including if the parent dies during launch.
GATE = """import os,sys
fd=int(sys.argv[1])
grant=os.read(fd,1)
os.close(fd)
if grant!=b'G': sys.exit(125)
os.execv(sys.argv[2],sys.argv[2:])
"""


def durable(path, record):
    tmp = path.with_suffix('.part')
    with tmp.open('w') as f:
        json.dump(record, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def subreaper():
    # Orphaned grandchildren in this job can be waited by this worker instead of the Pod's PID 1.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER')


def stat(pid):
    fields = Path('/proc', str(pid), 'stat').read_bytes().rsplit(b')', 1)[1].split()
    return dict(pid=pid, state=fields[0].decode('ascii'), ppid=int(fields[1]), pgid=int(fields[2]),
                sid=int(fields[3]), birth=fields[19].decode('ascii'))


def members(group):
    rows = []
    for entry in os.scandir('/proc'):
        if not entry.name.isdecimal():
            continue
        try:
            r = stat(int(entry.name))
        except (FileNotFoundError, ProcessLookupError):
            continue
        if r['pgid'] == group:
            if r['sid'] != group:
                raise RuntimeError('session mismatch')
            rows.append(r)
    return rows


def leader(p, birth):
    # No poll(), wait(), SIGCHLD handler or competing waiter before the last group signal.
    # Even an exited leader is still our child, so its PID/PGID cannot be recycled here.
    r = stat(p.pid)
    if (r['ppid'], r['pgid'], r['sid']) != (os.getpid(), p.pid, p.pid) or (birth is not None and birth != r['birth']):
        raise RuntimeError('lost process-group ownership')
    return r


def wait_exit(p, birth, deadline, stop):
    while not stop() and leader(p, birth)['state'] != 'Z':
        if time.monotonic() >= deadline:
            raise subprocess.TimeoutExpired(p.args, 0)
        time.sleep(.1)


def drain(p, birth, rec, grace, settle):
    # Pin the leader until the entire owned group is gone. Never signal from a disk receipt.
    def live(rows):
        return [r for r in rows if r['state'] not in ('Z', 'X')]

    def send(sig):
        leader(p, birth)
        try:
            os.killpg(p.pid, sig)
        except ProcessLookupError:
            pass
        rec['group_signals'].append(sig.name)

    leader(p, birth)
    rows = members(p.pid)
    rec['live_at_cleanup'] = [r['pid'] for r in live(rows)]
    if live(rows):
        send(signal.SIGTERM)
        until = time.monotonic() + grace
        while live(members(p.pid)) and time.monotonic() < until:
            time.sleep(.05)
        if live(members(p.pid)):
            send(signal.SIGKILL)

    until = time.monotonic() + settle
    while True:
        leader(p, birth)
        rows = members(p.pid)
        for r in rows:
            if r['pid'] != p.pid and r['ppid'] == os.getpid() and r['state'] == 'Z':
                pid, status = os.waitpid(r['pid'], os.WNOHANG)
                if pid:
                    rec['adopted_reaped'].append([pid, os.waitstatus_to_exitcode(status)])
        if len(rows) == 1 and rows[0]['pid'] == p.pid and rows[0]['state'] == 'Z':
            break
        if time.monotonic() >= until:
            raise TimeoutError('owned group did not drain: '+repr(rows))
        time.sleep(.05)
    rec['group_drained'] = True


def supervise(argv, env, log_path, end, record, occupancy, success_evidence, *, timeout=5400, grace=10, settle=10):
    """Emit a terminal receipt and return only on a clean exit; all failure paths stop the arm."""
    p = birth = caught = None
    old = {}
    read_fd = write_fd = None
    rec = dict(record, status='starting', reaped=False, group_drained=False, timeout_seconds=timeout, grant=False, grant_attempted=False,
               group_signals=[], adopted_reaped=[], errors=[], timed_out=False, child_exit=None, exit=None)

    def latch(sig, frame):
        nonlocal caught
        if caught is None:
            caught = sig   # No raise: in particular, cannot interrupt Popen before its return is assigned.

    def close_gate():
        nonlocal write_fd
        if write_fd is not None:
            os.close(write_fd)
            write_fd = None

    def error(where, exc):
        rec['errors'].append([where, repr(exc)])

    try:
        for sig in STOP:
            old[sig] = signal.signal(sig, latch)
        if signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL or signal.pthread_sigmask(signal.SIG_BLOCK, set()).intersection(STOP):
            raise RuntimeError('unexpected SIGCHLD disposition or blocked stop signals')
        # Install an ordinary default disposition (no inherited automatic reaping flags).
        signal.signal(signal.SIGCHLD, signal.SIG_DFL)
        subreaper()
        durable(end, rec)
        if caught is None:
            with log_path.open('x') as log:
                read_fd, write_fd = os.pipe()
                p = subprocess.Popen([sys.executable, '-I', '-S', '-B', '-c', GATE, str(read_fd), *argv],
                                     env=env, stdout=log, stderr=subprocess.STDOUT, pass_fds=(read_fd,),
                                     start_new_session=True)
                rec.update(pid=p.pid, birth=None)
                os.close(read_fd)
                read_fd = None
                birth = leader(p, None)['birth']
                rec.update(status='owned', pid=p.pid, pgid=p.pid, sid=p.pid, birth=birth)
                durable(end, rec)   # No training or descendants possible until this succeeds.
                if caught is None:
                    rec['grant_attempted'] = True
                    os.write(write_fd, b'G')
                    rec['grant'] = True
                close_gate()
                wait_exit(p, birth, time.monotonic()+timeout, lambda: caught is not None)
    except subprocess.TimeoutExpired as exc:
        rec['timed_out'] = True
        error('wait', exc)
    except BaseException as exc:
        error('run', exc)
    finally:
        close_gate()
        if read_fd is not None:
            os.close(read_fd)
        if p is not None:
            try:
                if rec['grant_attempted']:
                    drain(p, birth, rec, grace, settle)
                    if rec['live_at_cleanup'] and not (caught or rec['errors']):
                        error('unexpected surviving group members', rec['live_at_cleanup'])
                else:
                    # Refused gate: no payload was exec'd, so only the direct bootstrap is owned.
                    try:
                        p.wait(timeout=settle)
                    except subprocess.TimeoutExpired:
                        p.kill()
            except BaseException as exc:
                error('group cleanup', exc)
                # A broken /proc walk or diagnostic must not strand an admitted payload.
                # No wait/poll has yet occurred on this branch. Check direct-child ownership
                # without consuming its status, independently of the failing group walk.
                if rec['grant_attempted']:
                    try:
                        os.waitid(os.P_PID, p.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                        if (os.getpgid(p.pid), os.getsid(p.pid)) != (p.pid, p.pid):
                            raise RuntimeError('emergency group identity mismatch')
                        os.killpg(p.pid, signal.SIGKILL)
                        rec['group_signals'].append('SIGKILL')
                        drain(p, birth, rec, 0, settle)
                    except BaseException as emergency:
                        error('emergency cleanup', emergency)
            try:
                try:
                    rec['child_exit'] = p.wait(timeout=settle)
                except BaseException as wait_error:
                    error('final wait', wait_error)
                    # The group will never be signalled again. Recover a failed Popen wait
                    # only with this direct child, never waitpid(-1) or a PID from disk.
                    until = time.monotonic() + settle
                    while p.returncode is None:
                        if time.monotonic() >= until:
                            raise TimeoutError('could not reap direct child')
                        try:
                            pid, status = os.waitpid(p.pid, os.WNOHANG)
                        except InterruptedError:
                            continue
                        if pid:
                            p.returncode = os.waitstatus_to_exitcode(status)
                        else:
                            time.sleep(.05)
                    rec['child_exit'] = p.returncode
                rec['reaped'] = True
                if not rec['grant_attempted']:
                    rec['group_drained'] = True
            except BaseException as exc:
                error('reap', exc)
        try:
            rec['apps_after'] = occupancy()
            if rec['apps_after']:
                error('occupied after cleanup', rec['apps_after'])
        except BaseException as exc:
            rec['apps_after'] = None
            error('occupancy unavailable', exc)
        evidence = {}
        if caught is None and not rec['errors'] and rec['child_exit'] == 0 and rec['reaped'] and rec['group_drained']:
            try:
                evidence = success_evidence()
            except BaseException as exc:
                error('success evidence', exc)
        # The terminal commit is the linearization point. A stop after it cannot orphan work.
        mask = signal.pthread_sigmask(signal.SIG_BLOCK, STOP)
        try:
            rec['stop_signal'] = caught or next((int(s) for s in STOP if s in signal.sigpending()), None)
            rc = (128+rec['stop_signal'] if rec['stop_signal'] else 124 if rec['timed_out'] else
                  1 if rec['errors'] or not rec['reaped'] or not rec['group_drained'] else rec['child_exit'])
            if rc == 0:
                rec.update(evidence)
            rec.update(exit=rc, status='failed' if rc else 'passed', terminal=True)
            durable(end, rec)
        finally:
            for sig, handler in old.items():
                signal.signal(sig, handler)
            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
    if rec['exit'] != 0:
        raise RuntimeError('arm failed; inspect terminal receipt; do not retry')
