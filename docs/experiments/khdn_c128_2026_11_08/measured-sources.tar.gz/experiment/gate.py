from pathlib import Path
import importlib.util,json,os,sys,time
D=Path(__file__).resolve().parent;O=Path(os.environ['BF16_PROBE_OUT'])
sys.path[:0]=[str(D/'repo'),str(D/'candidate')]
import torch
from fla.ops.key_gated_hyperbolic_delta_rule import chunk_key_gated_hyperbolic_delta_rule as public
from fla.ops.key_gated_hyperbolic_delta_rule import chunk128 as baseline
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
spec=importlib.util.spec_from_file_location('paired_host',D/'candidate/host.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
candidate.PAIR_WARPS=int(os.environ['PAIR_WARPS']);assert candidate.PAIR_WARPS in (8,16)
torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
original=baseline.chunk_bf16;native_launch=candidate.launch;resources={};calls=[]
def observed(kernel,grid,args,telemetry,**kw):
 image=native_launch(kernel,grid,args,telemetry,**kw);calls.append(kernel.__name__)
 if 'interval' in kernel.__name__ or kernel.__name__=='common_lower_kernel':resources[kernel.__name__]=dict(regs=image.n_regs,spills=image.n_spills,shared=image.metadata.shared,warps=image.metadata.num_warps,grid=list(grid))
 return image
candidate.launch=observed
cases=[(257,.5,128,False,'none',None,torch.float32,1.),(129,0.,128,False,'none',None,torch.float32,1.),
       (129,.5,64,False,'first',None,torch.float32,.7),(129,.5,128,False,'internal',None,torch.float32,1.),
       (129,.5,64,False,'none','mixed',torch.float32,1.),(257,.5,128,True,'none',None,torch.bfloat16,1.),
       (129,.5,32,False,'none',None,torch.float32,1.),(257,.5,128,False,'none','distinct',torch.bfloat16,1.)]
rows=[]
real_empty,real_empty_like=torch.empty,torch.empty_like

def poisoned(function):
 def allocate(*args,**kwargs):
  value=function(*args,**kwargs)
  if value.is_cuda and value.is_floating_point():
   with torch.no_grad():value.fill_(float('nan'))
  return value
 return allocate

torch.empty,torch.empty_like=poisoned(real_empty),poisoned(real_empty_like)
try:
 for index,(length,curvature,vd,packed,strong,levels,dtype,kscale) in enumerate(cases):
  torch.manual_seed(8013+index)
  shape=(1,length,1,128)
  q=torch.nn.functional.normalize(torch.randn(shape),dim=-1).to(dtype)
  k=(torch.nn.functional.normalize(torch.randn(shape),dim=-1)*kscale).to(dtype)
  v=.025*torch.randn(1,length,1,vd)
  if levels=='mixed':v[...,:32]=.3;v[...,32:]=.7
  if levels=='distinct':v*=torch.arange(1,vd//32+1).repeat_interleave(32)
  v=v.to(dtype);beta=torch.sigmoid(torch.randn(1,length,1));beta[:,0]=0;beta[:,1]=1
  ell=-.02-.08*torch.rand(shape)
  if strong=='first':ell[:,0]=-1e8;ell[:,1]=-1
  if strong=='internal':ell[:,7]=-1e8;ell[:,8]=-1
  bounds=torch.tensor([0,0,129,length,length],dtype=torch.int64) if packed else None
  state=.001*torch.randn(4 if packed else 1,1,128,vd);curve=torch.tensor(curvature)
  cpu=(q,k,v,beta,ell,state,curve);ref=tuple(x.double().requires_grad_() for x in cpu)
  expected=truth(*ref[:5],initial_state=ref[5],curvature=ref[6],group_size=32,output_final_state=True,cu_seqlens=bounds)
  xs=tuple(x.cuda().requires_grad_() for x in cpu);cu=None if bounds is None else bounds.cuda()
  cot=[.03*torch.randn(x.shape,device='cuda',dtype=(dtype if i==0 else torch.float32)) for i,x in enumerate(expected)]
  ref_grad=torch.autograd.grad(expected,ref,[x.cpu().double() for x in cot])
  metrics=[];observations={}
  for route,entry in [('baseline',original),('paired',candidate.chunk_bf16)]:
   baseline.chunk_bf16=entry;calls.clear()
   with _NoFP64Training():
    info={};out=public(*xs[:5],initial_state=xs[5],curvature=xs[6],group_size=32,chunk_size=128,precision_policy='bf16',output_final_state=True,cu_seqlens=cu,telemetry=info)
    grads=torch.autograd.grad(out,xs,cot)
   observations[route]=[x.detach().cpu().double() for x in (*out,*grads)]
   if route=='paired':
    assert calls.count('state_fwd_kernel')==calls.count('state_bwd_kernel')==1
    assert calls.count('interval_fwd_cross')==calls.count('interval_bwd_cross')==1
    assert resources['interval_fwd_cross']['grid'][1]==4 and resources['interval_bwd_cross']['grid'][1:]==[2,2]
   for i,(name,x,y) in enumerate(zip(['output','final','dq','dk','dv','dbeta','dell','ds0','dc'],observations[route],(*expected,*ref_grad))):
    y=y.detach();atol,rtol,budget=(.002,.02,.01) if i<2 else (.005,.03,.015)
    rms=float((x-y).square().mean().sqrt());limit=budget*max(float(y.square().mean().sqrt()),atol)
    bad=int((~torch.isclose(x,y,atol=atol,rtol=rtol)).sum());finite=bool(torch.isfinite(x).all())
    metrics.append(dict(route=route,source=name,bad=bad,rms=rms,limit=limit,finite=finite,passed=finite and bad==0 and rms<=limit))
  rows.append(dict(case=index,length=length,curvature=curvature,vd=vd,packed=packed,strong=strong,levels=levels,dtype=str(dtype),kscale=kscale,metrics=metrics,paired_vs_baseline_max=[float((a-b).abs().max()) for a,b in zip(observations['paired'],observations['baseline'])]))
  (O/'progress.json').write_text(json.dumps(dict(rows=rows,resources=resources),indent=2))
  print('GATE',index,all(m['passed'] for m in metrics),[(m['route'],m['source'],m['bad'],m['rms'],m['limit']) for m in metrics if not m['passed']],flush=True)
finally:
 baseline.chunk_bf16=original
 torch.empty,torch.empty_like=real_empty,real_empty_like
result=dict(status='M64_INTERVAL_GATE_PASS' if len(rows)==len(cases) and all(m['passed'] for row in rows for m in row['metrics']) else 'M64_INTERVAL_GATE_FAIL',rows=rows,resources=resources,warps=candidate.PAIR_WARPS)
(O/'result.json').write_text(json.dumps(result,indent=2));assert result['status']=='M64_INTERVAL_GATE_PASS'
