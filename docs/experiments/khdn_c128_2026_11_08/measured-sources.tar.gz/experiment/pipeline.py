from pathlib import Path
import json,os,subprocess,hashlib
D=Path(__file__).resolve().parent;O=D.parent
R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
manifest=json.loads((D/'source-manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256((D/'repo'/name).read_bytes()).hexdigest()==digest,name

def run(name,script,arm=''):
 out=O/name;out.mkdir()
 env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+name,
          PAIRED_ARM=arm,SCREEN_VARIANT='kda_matched' if arm=='kda_matched' else 'khdn_c128',
          FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
 with (out/'process.log').open('w') as log:
  subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/script)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 result=json.loads((out/'result.json').read_text());print(name,result['status'],result.get('medians_ms'),flush=True)
 return result

gate=run('gate','gate.py');assert gate['status']=='M64_INTERVAL_GATE_PASS'
base=run('base','model_screen.py','khdn_base')
pair=run('pair','model_screen.py','khdn_m64')
kda=run('kda','model_screen.py','kda_matched')
result=dict(status='M64_INTERVAL_RESEARCH_COMPLETE',warps=int(os.environ['PAIR_WARPS']),baseline=base,candidate=pair,matched_kda=kda,
            candidate_over_baseline={k:pair['medians_ms'][k]/base['medians_ms'][k] for k in ['fb','step']},
            candidate_over_matched_kda={k:pair['medians_ms'][k]/kda['medians_ms'][k] for k in ['fb','step']})
(O/'result.json').write_text(json.dumps(result,indent=2))
