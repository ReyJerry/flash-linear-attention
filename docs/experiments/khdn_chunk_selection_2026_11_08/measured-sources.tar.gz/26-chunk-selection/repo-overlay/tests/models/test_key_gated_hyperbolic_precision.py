# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

# ruff: noqa: E402
"""Precision dispatch checks and separately guarded native BF16 model regressions."""
import copy
import json

import pytest
import torch
import torch.nn.functional as F
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_leaves

# autopep8: off
pytest.importorskip('triton', reason='Actual FLA imports require the Triton runtime.')
pytest.importorskip('transformers')

import fla.modules.mlp as mlp
import fla.ops.key_gated_hyperbolic_delta_rule as ops
from fla.layers import KeyGatedHyperbolicDeltaNet
from fla.models import KeyGatedHyperbolicDeltaNetConfig, KeyGatedHyperbolicDeltaNetForCausalLM
from fla.models.cache_utils import Cache
from fla.ops.key_gated_hyperbolic_delta_rule import bf16
from fla.utils import IS_NVIDIA, device

# autopep8: on


def configuration(**kwargs):
    values = dict(hidden_size=64, head_dim=32, num_heads=2, num_hidden_layers=2,
                  intermediate_size=128, vocab_size=97, group_size=32, curvature=.6,
                  use_short_conv=False, fuse_norm=False, fuse_swiglu=False,
                  fuse_cross_entropy=False, attn_mode='chunk', use_cache=False)
    values.update(kwargs)
    return KeyGatedHyperbolicDeltaNetConfig(**values)


@pytest.mark.parametrize('policy', ['mixed_readout', 'bf16_fs6', 'bf16'])
def test_default_legacy_and_new_configuration_roundtrip(tmp_path, policy):
    default = configuration()
    assert default.precision_policy == 'strict'
    old = default.to_dict()
    old.pop('precision_policy')
    assert KeyGatedHyperbolicDeltaNetConfig.from_dict(old).precision_policy == 'strict'
    chosen = configuration(precision_policy=policy)
    chosen.save_pretrained(tmp_path)
    assert json.loads((tmp_path/'config.json').read_text())['precision_policy'] == policy
    loaded = KeyGatedHyperbolicDeltaNetConfig.from_pretrained(tmp_path)
    model = KeyGatedHyperbolicDeltaNetForCausalLM(loaded)
    assert all(block.attn.precision_policy == policy for block in model.model.layers)


@pytest.mark.parametrize('policy', ['unknown', True, None])
def test_invalid_policy_rejected_by_both_entries(policy):
    with pytest.raises(ValueError, match='precision_policy'):
        configuration(precision_policy=policy)
    with pytest.raises(ValueError, match='precision_policy'):
        KeyGatedHyperbolicDeltaNet(precision_policy=policy)


@pytest.mark.parametrize('policy', ['mixed_readout', 'bf16_fs6'])
@pytest.mark.parametrize('mode', ['naive', 'fused_recurrent'])
def test_explicit_unsupported_mode_is_not_silently_treated_as_mixed(mode, policy):
    with pytest.raises(ValueError, match='requires'):
        configuration(attn_mode=mode, precision_policy=policy)
    with pytest.raises(ValueError, match='requires'):
        KeyGatedHyperbolicDeltaNet(mode=mode, precision_policy=policy)


@pytest.mark.parametrize('policy', ['strict', 'mixed_readout', 'bf16_fs6', 'bf16'])
def test_real_model_layers_forward_explicit_policy_and_preserve_parameter_gradients(monkeypatch, policy):
    calls = []

    def observed(*args, **kwargs):
        calls.append(kwargs.copy())
        kwargs.pop('precision_policy', None)
        kwargs.pop('chunk_size')
        kwargs.pop('carry_mode')
        return ops.naive_recurrent_key_gated_hyperbolic_delta_rule(*args, **kwargs)

    monkeypatch.setattr(ops, 'chunk_key_gated_hyperbolic_delta_rule', observed)
    # The non-fused MLP still calls a CUDA-only activation; this test observes CPU policy wiring.
    monkeypatch.setattr(mlp, 'swiglu', lambda gate, value: F.silu(gate) * value)
    torch.manual_seed(12)
    model = KeyGatedHyperbolicDeltaNetForCausalLM(configuration(precision_policy=policy)).train()
    token = torch.randint(0, 97, (2, 5))
    result = model(input_ids=token, labels=token)
    result.loss.backward()
    assert len(calls) == 2
    for call in calls:
        assert call.get('precision_policy', 'strict') == policy
        if policy == 'strict':
            assert 'precision_policy' not in call
    assert all(param.grad is not None and torch.isfinite(param.grad).all() for param in model.parameters())


@pytest.mark.parametrize('policy', ['mixed_readout', 'bf16_fs6'])
def test_mixed_prefill_configuration_uses_strict_recurrent_decode(monkeypatch, policy):
    calls = []

    def observed(*args, **kwargs):
        calls.append(kwargs.copy())
        kwargs.pop('checkpoint_size')
        return ops.naive_recurrent_key_gated_hyperbolic_delta_rule(*args, **kwargs)

    monkeypatch.setattr(ops, 'fused_recurrent_key_gated_hyperbolic_delta_rule', observed)
    layer = KeyGatedHyperbolicDeltaNet(hidden_size=64, head_dim=32, num_heads=2, group_size=32,
                                       mode='chunk', precision_policy=policy,
                                       use_short_conv=False, fuse_norm=False, layer_idx=0).eval()
    with torch.no_grad():
        result = layer(torch.randn(1, 1, 64))[0]
    assert result.shape == (1, 1, 64) and len(calls) == 1
    assert 'precision_policy' not in calls[0]


@pytest.mark.parametrize('mode', ['chunk', 'fused_recurrent'])
def test_bf16_decode_preserves_precision_policy(monkeypatch, mode):
    calls = []

    def observed(*args, **kwargs):
        calls.append(kwargs.copy())
        assert kwargs.pop('precision_policy') == 'bf16'
        kwargs.pop('checkpoint_size')
        return ops.naive_recurrent_key_gated_hyperbolic_delta_rule(*args, **kwargs)

    monkeypatch.setattr(ops, 'fused_recurrent_key_gated_hyperbolic_delta_rule', observed)
    layer = KeyGatedHyperbolicDeltaNet(hidden_size=64, head_dim=32, num_heads=2, group_size=32,
                                       mode=mode, precision_policy='bf16', use_short_conv=False,
                                       fuse_norm=False, layer_idx=0).eval()
    with torch.no_grad():
        result = layer(torch.randn(1, 1, 64))[0]
    assert result.shape == (1, 1, 64) and len(calls) == 1


def test_bf16_naive_mode_rejected():
    with pytest.raises(ValueError, match='native'):
        configuration(attn_mode='naive', precision_policy='bf16')
    with pytest.raises(ValueError, match='native'):
        KeyGatedHyperbolicDeltaNet(mode='naive', precision_policy='bf16')


class NoFP64(TorchDispatchMode):
    def __torch_dispatch__(self, function, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        assert not any(isinstance(x, torch.Tensor) and x.dtype == torch.float64 for x in tree_leaves((args, kwargs)))
        result = function(*args, **kwargs)
        assert not any(isinstance(x, torch.Tensor) and x.dtype == torch.float64 for x in tree_leaves(result))
        return result


@pytest.fixture
def native_bf16_model(monkeypatch):
    if not IS_NVIDIA:
        pytest.skip('Native BF16 model validation requires NVIDIA CUDA.')
    try:
        bf16._require_runtime(torch.zeros((), device=device))
    except ValueError as error:
        pytest.skip(str(error))
    torch.manual_seed(42)
    original = bf16.chunk_bf16
    routes = []

    def observed(*args, **kwargs):
        info = {}
        kwargs['telemetry'] = info
        result = original(*args, **kwargs)
        assert info['precision_route'] == 'bf16' and not info['host_fallback']
        assert info['native_kernel_calls'] > 0
        routes.append((kwargs['q'].shape[1], kwargs['chunk_size']))
        return result

    monkeypatch.setattr(bf16, 'chunk_bf16', observed)

    def build(**kwargs):
        options = dict(hidden_size=256, head_dim=128, intermediate_size=512, chunk_size=16,
                       precision_policy='bf16', learnable_curvature=True, use_short_conv=True)
        options.update(kwargs)
        return KeyGatedHyperbolicDeltaNetForCausalLM(configuration(**options)).to(device)

    return build, routes


def compare_native_model(actual, expected):
    assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
    a, b = actual.float(), expected.float()
    torch.testing.assert_close(a, b, atol=.002, rtol=.02)
    assert (a-b).square().mean().sqrt() <= .01 * b.square().mean().sqrt().clamp_min(.002)


@pytest.mark.parametrize('short_conv', [False, True])
@pytest.mark.parametrize('carry', ['no_carry', 'y_carry'])
def test_native_bf16_cache_prefill_decode_reorder(native_bf16_model, short_conv, carry):
    build, routes = native_bf16_model
    model = build(use_short_conv=short_conv, carry_mode=carry).eval()
    ids = torch.randint(1, 97, (2, 70), device=device)
    with NoFP64(), torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
        expected = model(ids[:, :69], use_cache=True)
        prefix = model(ids[:, :65], use_cache=True)
        cache = Cache.from_legacy_cache(copy.deepcopy(prefix.past_key_values.to_legacy_cache()), seen_tokens=65)
        outputs = [prefix.logits]
        for pos in range(65, 69):
            outputs.append(model(ids[:, pos:pos+1], past_key_values=cache, use_cache=True).logits)
        compare_native_model(torch.cat(outputs, 1), expected.logits)
        for index in range(2):
            compare_native_model(cache[index]['recurrent_state']['state'],
                                 expected.past_key_values[index]['recurrent_state']['state'])
            assert cache[index]['recurrent_state']['state'].dtype == torch.float32
        before = copy.deepcopy(cache.to_legacy_cache())
        order = torch.tensor([1, 0], device=device)
        cache.reorder_cache(order)
        for index in range(2):
            torch.testing.assert_close(cache[index]['recurrent_state']['state'],
                                       before[index]['recurrent_state']['state'][order], atol=0, rtol=0)
        next_step = model(ids[order, 69:], past_key_values=cache, use_cache=True)
        complete = model(ids[order], use_cache=False)
        compare_native_model(next_step.logits, complete.logits[:, 69:])
        for beams in (1, 2):
            generated = model.generate(ids[:, :3], do_sample=False, num_beams=beams, max_new_tokens=2, eos_token_id=None)
            assert generated.shape == (2, 5)
        model.model.layers[0].attn.curvature_raw.add_(.1)
        with pytest.raises(ValueError, match='stale'):
            model(ids[:, :1], past_key_values=cache, use_cache=True)
    assert (69, 16) in routes and (65, 16) in routes and (1, 1) in routes


@pytest.mark.parametrize('short_conv', [False, True])
def test_native_bf16_packed_empty_and_labels(native_bf16_model, short_conv):
    build, routes = native_bf16_model
    model = build(use_short_conv=short_conv).eval()
    ids = torch.randint(1, 97, (1, 70), device=device)
    labels = ids.clone()
    cu = torch.tensor([0, 33, 33, 70], dtype=torch.int64, device=device)
    with NoFP64(), torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
        packed = model(ids, labels=labels, cu_seqlens=cu, use_cache=True)
        left = model(ids[:, :33], labels=ids[:, :33], use_cache=False)
        right = model(ids[:, 33:], labels=ids[:, 33:], use_cache=False)
        compare_native_model(packed.logits, torch.cat((left.logits, right.logits), 1))
        torch.testing.assert_close(packed.loss, (32*left.loss+36*right.loss)/68, atol=.002, rtol=.002)
        for index in range(2):
            assert torch.count_nonzero(packed.past_key_values[index]['recurrent_state']['state'][1]) == 0
        empty = model(ids[:, :0], use_cache=True)
        assert empty.logits.shape == (1, 0, 97)
    torch.testing.assert_close(labels, ids, atol=0, rtol=0)
    assert (70, 16) in routes and (33, 1) in routes and (37, 1) in routes and (0, 1) in routes


@pytest.mark.parametrize('checkpoint', [False, True])
def test_native_bf16_save_load_next_update(native_bf16_model, tmp_path, checkpoint):
    build, routes = native_bf16_model
    model = build().train()

    def optimizer_for(candidate):
        excluded, regular = [], []
        for param in candidate.parameters():
            (excluded if getattr(param, '_no_weight_decay', False) else regular).append(param)
        return torch.optim.AdamW([dict(params=excluded, weight_decay=0.), dict(params=regular, weight_decay=.1)], lr=1e-4)

    def update(candidate, optimizer, tokens):
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast('cuda', dtype=torch.bfloat16):
            result = candidate(tokens, labels=tokens, use_cache=False)
        assert torch.isfinite(result.loss)
        result.loss.backward()
        gradients = {}
        for name, param in candidate.named_parameters():
            assert param.grad is not None and torch.isfinite(param.grad).all(), name
            gradients[name] = param.grad.clone()
        optimizer.step()
        return result.loss.detach(), gradients

    with NoFP64():
        if checkpoint:
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
        optimizer = optimizer_for(model)
        ids = torch.randint(1, 97, (2, 17), device=device)
        update(model, optimizer, ids)
        model.save_pretrained(tmp_path)
        saved_optimizer = copy.deepcopy(optimizer.state_dict())
        restored, loading = KeyGatedHyperbolicDeltaNetForCausalLM.from_pretrained(tmp_path, output_loading_info=True)
        assert not loading['missing_keys'] and not loading['unexpected_keys']
        restored = restored.to(device).train()
        assert restored.config.precision_policy == 'bf16'
        if checkpoint:
            restored.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
        resumed = optimizer_for(restored)
        resumed.load_state_dict(saved_optimizer)
        next_ids = torch.randint(1, 97, (2, 17), device=device)
        original_loss, original_grads = update(model, optimizer, next_ids)
        loaded_loss, loaded_grads = update(restored, resumed, next_ids)
        torch.testing.assert_close(loaded_loss, original_loss, atol=0, rtol=0)
        for name, param in model.named_parameters():
            torch.testing.assert_close(loaded_grads[name], original_grads[name], atol=0, rtol=0)
            torch.testing.assert_close(restored.get_parameter(name), param, atol=0, rtol=0)
        for key, state in optimizer.state_dict()['state'].items():
            for name, value in state.items():
                torch.testing.assert_close(resumed.state_dict()['state'][key][name], value, atol=0, rtol=0)
        for block in restored.model.layers:
            assert block.attn.A_log.dtype == block.attn.dt_bias.dtype == block.attn.curvature_raw.dtype == torch.float32
            assert block.attn.A_log._no_weight_decay and block.attn.dt_bias._no_weight_decay
    assert routes and all(chunk == 16 for _, chunk in routes)
