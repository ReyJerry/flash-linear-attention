"""Short full-model cost screen; not final numerical or throughput qualification."""
from pathlib import Path
import collections
import gc
import importlib
import importlib.util
import json
import os
import statistics
import sys

D = Path(__file__).resolve().parent
sys.path[:0]=[str(D/'repo'),str(D/'baseline'),str(D/'candidate'),str(D)]
os.environ['FLA_SOURCE_MANIFEST']=str(D/'source-manifest.json')
os.chdir(D/'repo')
import cache_bootstrap as boot
import torch
from triton.runtime.autotuner import Autotuner
from benchmarks import benchmark_hyperbolic_training as b, hyperbolic_training_distributed as h
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
from control_model import apply_full_output_projection
from benchmarks import fp32_adamw

O = Path(os.environ['BF16_PROBE_OUT'])
variant = os.environ['PAIRED_ARM']
execution_chunk = int(os.environ.get('FLEX_CHUNK', '128'))
assert execution_chunk in (16,32,64,128)
assert variant in ('khdn_base','khdn_combined','kda_matched')
torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32 = False

def refuse(*args, **kwargs):
    raise RuntimeError('Unfrozen shared-kernel tuning requested')

Autotuner._bench = refuse
arguments=list(boot.plan['arguments'])
arguments[arguments.index('--chunk-size')+1]='128'
arguments[arguments.index('--khdn-precision-policy')+1]='bf16'
args=b.parse_arguments(arguments)
args.chunk_size=execution_chunk
args.batch, args.seq_len = 1, 16384
assert args.batch * args.seq_len == 16384
args.seed, args.data_seed, args.khdn_precision_policy = 101, 1009, 'bf16'
method = 'khdn_no_carry' if variant != 'kda_matched' else 'kda'
args.methods = [method]
counts = collections.Counter()
resources = {}
eligibility_rows = []
rho_routes = []

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

if variant != 'kda_matched':
    from fla.ops.key_gated_hyperbolic_delta_rule import chunk128 as live
    candidate = load('screen_core',D/'candidate/host.py')
    from fla.ops.key_gated_hyperbolic_delta_rule import bf16 as small_chunk_entry
    small_chunk_entry.chunk_bf16=candidate.chunk_bf16
    live.chunk_bf16=candidate.chunk_bf16
    if variant == 'khdn_combined':
        live.chunk_bf16=candidate.chunk_bf16
    original_launch = candidate.launch

    def observed(kernel, grid, values, telemetry, **kwargs):
        if variant=='khdn_combined' and kernel.__name__=='state_fwd_kernel':
            pp,gg=values[8],values[9]
            assert all(x.dtype==(torch.bfloat16 if i<18 and i not in (2,3,4) else torch.float32) for i,x in enumerate(pp))
            assert all(x.dtype==(torch.bfloat16 if i in (0,1,3,4) else torch.float32) for i,x in enumerate(gg))
            assert values[4].dtype==torch.float32
            assert all(values[j].dtype==torch.bfloat16 for j in (10,11,12))
            assert all(values[j].dtype==torch.float32 for j in (13,14,15,16))
        if variant=='khdn_combined' and kernel.__name__=='output_fwd_kernel':
            assert all(values[j].dtype==torch.bfloat16 for j in (6,7,10))
        result = original_launch(kernel, grid, values, telemetry, **kwargs)
        counts[kernel.__name__] += 1
        if kernel.__name__ == 'group_system_tiles':rho_routes.append(bool(kwargs['RHO_MATERIALIZED']))
        if kernel.__name__ == "diagonal_eligibility":
            eligibility_rows.append(dict(eligible=int(values[4].sum().item()), total=values[4].numel()))
        resources[kernel.__name__] = dict(registers=result.n_regs, spills=result.n_spills,
                                          shared=result.metadata.shared, warps=result.metadata.num_warps, grid=list(grid),
                                          wgmma=result.asm['ptx'].count('wgmma.mma_async'),
                                          mma_sync=result.asm['ptx'].count('mma.sync'),
                                          local_load_instructions=result.asm['ptx'].count('ld.local'))
        return result

    candidate.launch = observed
    from fla.ops.key_gated_hyperbolic_delta_rule import fused_prepare as native_preprocessing
    preprocessing = load('screen_preprocessing',D/'candidate/preprocessing.py')
    native_preprocessing.fused_preprocessing=preprocessing.fused_preprocessing
    if variant=='khdn_combined':native_preprocessing.fused_preprocessing=preprocessing.fused_preprocessing
    prepare_launch=preprocessing.launch
    def observed_prepare(kernel,grid,values,telemetry=None,**kw):
        result=prepare_launch(kernel,grid,values,telemetry,**kw)
        counts[kernel.__name__]+=1
        resources[kernel.__name__]=dict(registers=result.n_regs,spills=result.n_spills,shared=result.metadata.shared,grid=list(grid))
        return result
    preprocessing.launch=observed_prepare
    preprocessing_binding=dict(route='batch8_headfast_cachedproof',runtime_layer_patch=False)

else:
    kmod = importlib.import_module('fla.ops.kda.backends.tilelang.chunk_bwd_dqkg')
    original_kda = kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang

    def observed_kda(*values, **kwargs):
        counts['kda_tilelang_bwd'] += 1
        return original_kda(*values, **kwargs)

    kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang = observed_kda

def write(name, value):
    (O / name).write_text(json.dumps(value, indent=2, allow_nan=False))

with h.Runtime(args) as runtime, b.environment(b.method_spec(method)['environment']):
    assert runtime.world_size == 1
    model, info = b.build_model(args, b.method_spec(method), small=False)
    if variant == 'kda_matched':
        binding = apply_full_output_projection(model, seed=101)
    else:
        layers=[m for name,m in model.named_modules() if name in boot.plan['layer_names']]
        assert len(layers)==24 and all(layer.chunk_size==execution_chunk for layer in layers)
        assert model.config.chunk_size==execution_chunk
        binding=dict(execution_chunk=execution_chunk, mathematical_group=32, physical_state_value_tile=32, interval_cross_forward_tile=32 if execution_chunk==64 else 64, inverse_products=1, beta_product_tile=16,
                     state_warps=4, preprocessing=preprocessing_binding)
    assert sum(p.numel() for p in model.parameters()) == 1412912512
    assert len(list(model.parameters())) == 459
    optimizer = fp32_adamw.make_optimizer(model, args, h.optimizer_groups)
    h.enforce_optimizer_policy(model, optimizer, .1)
    rng = h.capture_rng()
    batch = h.make_batch(args, 0).to('cuda')
    with _NoFP64Training():
        loss = h.weighted_loss(model, batch, args, batch.valid_labels, 1)
        loss.backward()
        torch.cuda.synchronize()
    gradient_l2 = b.gradient_health(model)
    if variant != 'kda_matched':
        state_prefix=''
        if variant!='kda_matched':
            assert resources['common_products_kernel']['grid']==[16384//execution_chunk*16,(execution_chunk//16)**2]
            assert resources['preprocessing_fwd']['grid']==resources['preprocessing_bwd']['grid']==[16,2048]
        assert counts[state_prefix+'state_fwd_kernel']==48 and counts[state_prefix+'state_bwd_kernel']==24
        assert counts['preprocessing_fwd'] == 48 and counts['preprocessing_bwd'] == 24
        assert resources[state_prefix+'state_fwd_kernel']['grid']==[args.batch*16*4]
        assert resources['output_fwd_kernel']['grid'] == [16384//execution_chunk*16*4]
        candidate.launch = original_launch
        preprocessing.launch = prepare_launch
    else:
        assert counts['kda_tilelang_bwd'] == 24
        kmod.chunk_kda_bwd_wy_dqkg_fused_tilelang = original_kda
    write('qualification.json', dict(loss=float(loss.detach()), gradient_l2=gradient_l2,
          counts=dict(counts), resources=resources, eligibility=eligibility_rows, rho_materialized_routes=rho_routes, source_validation_fallbacks=getattr(candidate,'_source_validation_fallbacks',None) if variant!='kda_matched' else None, binding=binding, model=info,
          scope='Finite full24 initial forward/backward and actual route only; not cross-precision quality qualification.'))
    optimizer.zero_grad(set_to_none=True)
    h.restore_rng(rng)
    del loss, batch
    gc.collect()
    torch.cuda.empty_cache()
    rows = []
    physical = [0]
    hook = optimizer.register_step_post_hook(lambda *_: physical.__setitem__(0, physical[0]+1))
    for mode in ('fb', 'step'):
        for index in range(5):
            batch = h.make_batch(args, index).to('cuda')
            row = h.timed_sample(model, optimizer, [batch], args, runtime, mode)
            row.update(mode=mode, index=index, warmup=index < 2)
            rows.append(row)
            write('samples.json', rows)
            del batch
    hook.remove()
    assert physical[0] == 5
    assert len(optimizer.state) == 459 and all(int(v['step']) == 5 for v in optimizer.state.values())
    batch = h.make_batch(args, 5).to('cuda')
    optimizer.zero_grad(set_to_none=True)
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA],
                                record_shapes=False, profile_memory=False, with_stack=False) as profiler:
        loss = h.weighted_loss(model, batch, args, batch.valid_labels, 1)
        loss.backward()
        h.clip_and_step(model, optimizer, args)
        torch.cuda.synchronize()
    assert all(int(v['step']) == 6 for v in optimizer.state.values())
    profiler.export_chrome_trace(str(O/'trace.json.gz'))
    write('events.json', [dict(key=e.key, count=e.count, self_cpu_time_total=e.self_cpu_time_total,
                              cpu_time_total=e.cpu_time_total, device_time_total=e.device_time_total,
                              self_device_time_total=e.self_device_time_total) for e in profiler.key_averages()])
    write('optimizer-images.json', fp32_adamw.images)
    write('result.json', dict(optimizer_backend='triton_fp32_adamw',status='FLEXIBLE_CHUNK_FULL_MODEL_RESEARCH_SCREEN_COMPLETE', execution_chunk=execution_chunk, variant=variant,
          timed_optimizer_steps=physical[0], additional_profile_steps=1, physical_optimizer_steps=6,
          parameters=1412912512,
          medians_ms={mode:statistics.median(r['wall_ms'] for r in rows if r['mode']==mode and not r['warmup'])
                      for mode in ('fb', 'step')},
          peak_allocated=max(r['training_memory']['peak_allocated_bytes'] for r in rows),
          scope='Same-card full24 B1T16384 C64/C128/matchedKDA,2warm3steady FB and actual FP32AdamW step; research ranking only.'))
