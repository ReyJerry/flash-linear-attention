from pathlib import Path
import hashlib,json,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent
R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
for name,digest in json.loads((D/'source-manifest.json').read_text())['files'].items():assert hashlib.sha256((D/'repo'/name).read_bytes()).hexdigest()==digest
admission=json.loads((D/'admission.json').read_text());parent=Path(admission['root'])
receipt=json.loads((parent/'supervisor.json').read_text());assert receipt['terminal'] and receipt['reaped'] and receipt['group_drained'] and not receipt['apps_after'] and receipt['exit']==0
for name,digest in admission['candidate_files'].items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==digest and hashlib.sha256((parent/'payload'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256((parent/'result.json').read_bytes()).hexdigest()==admission['result_sha256']
gate=json.loads((parent/'result.json').read_text());assert len(gate['rows'])==8 and gate['all_passed'] and all(m['finite'] for r in gate['rows'] for m in r['metrics'])
(O/'retained-gates.json').write_text(json.dumps(gate,indent=2))
results={}
for name,chunk in [('kda',64),('c128',128),('c64',64)]:
 out=O/name;out.mkdir();env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+name,FLEX_CHUNK=str(chunk),PAIRED_ARM='kda_matched' if name=='kda' else 'khdn_combined',SCREEN_VARIANT='kda_matched' if name=='kda' else 'khdn_c128',FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
 with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'model_screen.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 results[name]=json.loads((out/'result.json').read_text());print(name,results[name]['medians_ms'],flush=True)
weights=[json.loads((O/name/'qualification.json').read_text())['model']['initial_weights_sha256'] for name in ('c64','c128')];assert weights[0]==weights[1]
(O/'result.json').write_text(json.dumps(dict(status='SAME_GENERATION_LONG_CHUNK_COST_SCREEN_COMPLETE',arms=results,c64_over_c128={k:results['c64']['medians_ms'][k]/results['c128']['medians_ms'][k] for k in ('fb','step')},scope='Research long-endpoint short-screen, same optimized source/precision/preprocessing and weights; no final numerical/quality/default choice solely from this record.'),indent=2))
