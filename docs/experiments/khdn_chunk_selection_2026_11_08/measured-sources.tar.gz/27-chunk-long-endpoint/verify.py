"""Independently recompute the short-screen summaries from saved observations."""
from pathlib import Path
import hashlib
import json
import statistics

D = Path(__file__).resolve().parent
R = D / 'collected'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R / 'result.json') == '066bc3754f2206059aac427a1db5c98d47e5454976eee02fd62ca6a37c0dd347'
s = read(R / 'supervisor.json')
assert s['terminal'] and s['reaped'] and s['group_drained']
assert s['exit'] == 0 and not s['apps_after']
assert s['archive'] == read(D / 'release.json')['archive']
result = read(R / 'result.json')
metrics = {}
qualifications = {}
sample_ids = {}
for arm in ('c64', 'c128', 'kda'):
    rows = read(R / arm / 'samples.json')
    assert len(rows) == 10
    r = read(R / arm / 'result.json')
    assert r == result['arms'][arm]
    assert r['physical_optimizer_steps'] == 6
    assert r['optimizer_backend'] == 'triton_fp32_adamw'
    assert r['parameters'] == 1412912512
    medians = {}
    for mode in ('fb', 'step'):
        group = [x for x in rows if x['mode'] == mode]
        assert [x['index'] for x in group] == list(range(5))
        assert [x['warmup'] for x in group] == [True, True, False, False, False]
        medians[mode] = statistics.median(x['wall_ms'] for x in group if not x['warmup'])
    assert medians == r['medians_ms']
    assert max(x['training_memory']['peak_allocated_bytes'] for x in rows) == r['peak_allocated']
    sample_ids[arm] = [x['samples'] for x in rows]
    assert all(x['input_slots'] == 16384 for x in rows)
    qualifications[arm] = read(R / arm / 'qualification.json')
    metrics[arm] = dict(medians_ms=medians, tokens_per_second=16384000 / medians['step'],
                        peak_allocated_bytes=r['peak_allocated'],
                        peak_reserved_bytes=max(x['training_memory']['peak_reserved_bytes'] for x in rows))
assert sample_ids['c64'] == sample_ids['c128'] == sample_ids['kda']
assert qualifications['c64']['model']['initial_weights_sha256'] == qualifications['c128']['model']['initial_weights_sha256']
for arm, c in (('c64', 64), ('c128', 128)):
    q = qualifications[arm]
    assert q['binding']['execution_chunk'] == c
    assert q['model']['configuration']['chunk_size'] == c
    assert q['resources']['state_fwd_kernel']['grid'] == [64]
    assert q['resources']['output_fwd_kernel']['grid'] == [16384 // c * 16 * 4]
    assert q['counts']['state_fwd_kernel'] == 48 and q['counts']['state_bwd_kernel'] == 24
assert qualifications['kda']['counts']['kda_tilelang_bwd'] == 24
out = dict(status='MAIN_LONG_ENDPOINT_SCREEN_VERIFIED', metrics=metrics,
           c64_throughput_gain_over_c128=metrics['c128']['medians_ms']['step'] / metrics['c64']['medians_ms']['step'] - 1,
           c64_throughput_fraction_of_kda=metrics['kda']['medians_ms']['step'] / metrics['c64']['medians_ms']['step'],
           c64_peak_saving_bytes=metrics['c128']['peak_allocated_bytes'] - metrics['c64']['peak_allocated_bytes'],
           evidence_files={str(p.relative_to(R)): sha(p) for p in R.rglob('*') if p.is_file()},
           limits=['One 2-warm/3-steady long-shape screening round; not final performance qualification.',
                   'Original public 12-case numerical failures remain unresolved.',
                   'C64 cross-forward32 / C128 cross-forward64 explicitly recorded.',
                   'source_validation_fallbacks=null is uninstrumented, not an observed zero.',
                   'Current-source numerical/model/distributed acceptance and formal repeated timing remain incomplete.'])
(D / 'verified.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items() if k != 'evidence_files'}, indent=2))
