from pathlib import Path
import hashlib
import importlib
import json
import math
import os
import sys
import traceback

D = Path(__file__).resolve().parent
O = D.parent
sys.path[:0] = [str(D/'repo'), str(D/'variants')]
os.environ['FLA_SOURCE_MANIFEST'] = str(D/'source-manifest.json')
for name,digest in json.loads((D/'source-manifest.json').read_text())['files'].items():
    assert hashlib.sha256((D/'repo'/name).read_bytes()).hexdigest()==digest
import torch
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
from fla.ops.key_gated_hyperbolic_delta_rule import bf16, chunk128, chunk_key_gated_hyperbolic_delta_rule as call
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth

torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32=False
hosts={n:importlib.import_module('host_'+n) for n in ('base','diag32')}
original128,originalsmall=chunk128.chunk_bf16,bf16.chunk_bf16
q=torch.zeros(1,1,1,128);q[...,0]=1
source=(q,q.clone(),torch.full((1,1,1,32),.9998779296875),torch.full((1,1,1),.5),
        torch.zeros_like(q),torch.zeros(1,1,128,32),torch.tensor(1.))
reference=tuple(x.double().requires_grad_() for x in source)
expected=truth(*reference[:5],curvature=reference[6],initial_state=reference[5],group_size=32,output_final_state=True)
torch.manual_seed(629)
cot=tuple(torch.randn(x.shape,dtype=torch.float32) for x in expected)
refgrad=torch.autograd.grad(expected,reference,[x.double() for x in cot])
xs=tuple(x.cuda().requires_grad_() for x in source);cot=tuple(x.cuda() for x in cot)
domain=float(source[1].square().sum()-source[6]/32*source[2].square().sum())
assert domain>0
rows=[]
def number(x):
    f=float(x);return f if math.isfinite(f) else str(f)
for variant,c in [('published',128),('base',64),('base',128),('diag32',64),('diag32',128)]:
    module=chunk128 if variant=='published' else hosts[variant]
    chunk128.chunk_bf16=original128 if variant=='published' else module.chunk_bf16
    bf16.chunk_bf16=originalsmall if variant=='published' else module.chunk_bf16
    launches=[];images={};original_launch=module.launch
    def observed(kernel,grid,args,telemetry,**kw):
        compiled=original_launch(kernel,grid,args,telemetry,**kw)
        item=dict(kernel=kernel.__name__,grid=list(grid))
        gp=None
        if kernel.__name__=='group_gram_kernel':gp=args[3]
        if kernel.__name__ in ('group_gauge_kernel','group_system_tiles','group_feedback_tiles'):gp=args[2]
        if gp is not None:
            for i,label in ((3,'gram_diag'),(1,'system_diag'),(0,'inverse_diag')):
                if (kernel.__name__,i) in [('group_gram_kernel',3),('group_system_tiles',1),('group_feedback_tiles',0)]:
                    item[label]=number(gp[i][0,0,0].detach().float().cpu())
            if kernel.__name__=='group_gauge_kernel':
                item['lambda0']=number(gp[6][0,0].detach().cpu());item['nu0']=number(gp[7][0,0].detach().cpu())
        launches.append(item)
        digest=hashlib.sha256(compiled.asm['ttir'].encode()).hexdigest()
        if digest not in images:
            folder=O/'images';folder.mkdir(exist_ok=True)
            for kind in ('ttir','ptx'):(folder/(digest+'.'+kind)).write_text(compiled.asm[kind])
            images[digest]=kernel.__name__
        return compiled
    module.launch=observed
    before=getattr(module,'_source_validation_fallbacks',0);info={}
    row=dict(variant=variant,chunk=c,raw_margin_fp32=domain)
    try:
        with _NoFP64Training():
            actual=call(*xs[:5],curvature=xs[6],initial_state=xs[5],group_size=32,output_final_state=True,
                        chunk_size=c,precision_policy='bf16',telemetry=info)
            grad=torch.autograd.grad(actual,xs,cot)
            torch.cuda.synchronize()
        metrics=[]
        for i,(name,a,b) in enumerate(zip(('output','final','dq','dk','dv','dbeta','dell','dS0','dc'),(*actual,*grad),(*expected,*refgrad))):
            a=a.detach().cpu().double();b=b.detach();atol,rtol,budget=(.002,.02,.01) if i<2 else (.005,.03,.015)
            rms=float((a-b).square().mean().sqrt());limit=budget*max(atol,float(b.square().mean().sqrt()))
            bad=int((~torch.isclose(a,b,atol=atol,rtol=rtol)).sum());finite=bool(torch.isfinite(a).all())
            metrics.append(dict(source=name,finite=finite,max_abs=number((a-b).abs().max()),rms=number(rms),limit=limit,bad=bad,passed=finite and bad==0 and rms<=limit))
        row['metrics']=metrics;row['passed']=all(m['passed'] for m in metrics)
    except Exception as error:
        row.update(passed=False,error=repr(error),traceback=traceback.format_exc())
        if 'CUDA error' in str(error):raise
    finally:module.launch=original_launch
    row.update(launches=launches,images=images,telemetry=info,source_guard_fallbacks=getattr(module,'_source_validation_fallbacks',0)-before)
    rows.append(row);(O/'progress.json').write_text(json.dumps(rows,indent=2));print(variant,c,row['passed'],row.get('error'),row.get('metrics'),flush=True)
chunk128.chunk_bf16,bf16.chunk_bf16=original128,originalsmall
(O/'result.json').write_text(json.dumps(dict(status='RAW_BOUNDARY_DIAGNOSIS_COMPLETE',rows=rows,
    scope='Exact B3 legal raw input only, independent untimed CPUFP64 truth; not default-layer root cause or general-domain qualification.'),indent=2))
