from pathlib import Path
import importlib.util,json,os,sys
D=Path(__file__).resolve().parent;O=Path(os.environ['BF16_PROBE_OUT']);sys.path[:0]=[str(D/'repo'),str(D/'candidate')]
import torch
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
spec=importlib.util.spec_from_file_location('flex_host',D/'candidate/host.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
spec=importlib.util.spec_from_file_location('dead_base_host',D/'candidate/base_host.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
original_launch=candidate.launch
poison_checks=[]
def observed(kernel,grid,args,telemetry,**kwargs):
 result=original_launch(kernel,grid,args,telemetry,**kwargs)
 if kernel.__name__ in ('common_input_kernel','common_products_kernel','interval_cache_kernel'):
  p=args[5] if kernel.__name__=='common_input_kernel' else args[0] if kernel.__name__=='common_products_kernel' else args[3]
  predicate=torch.isfinite if kernel.__name__=='interval_cache_kernel' else torch.isnan
  assert all(bool(predicate(p[i]).all()) for i in (3,4)),kernel.__name__
  poison_checks.append(kernel.__name__)
 return result
candidate.launch=observed
torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
real_empty,real_empty_like=torch.empty,torch.empty_like

def poison(fn):
 def allocate(*args,**kw):
  x=fn(*args,**kw)
  if x.is_cuda and x.is_floating_point():
   with torch.no_grad():x.fill_(float('nan'))
  return x
 return allocate

torch.empty,torch.empty_like=poison(real_empty),poison(real_empty_like)
rows=[]
try:
 for chunk in (16,32,64,128):
  for packed in (False,True):
   torch.manual_seed(702+int(packed));length=2*chunk+1;shape=(1,length,1,128)
   q=torch.nn.functional.normalize(torch.randn(shape),dim=-1);k=torch.nn.functional.normalize(torch.randn(shape),dim=-1)
   v=.025*torch.randn(shape);beta=torch.sigmoid(torch.randn(1,length,1));beta[:,0]=0;beta[:,1]=1;ell=-.02-.08*torch.rand(shape)
   bounds=torch.tensor([0,0,chunk+1,length,length],dtype=torch.int64) if packed else None
   state=.001*torch.randn(4 if packed else 1,1,128,128);c=torch.tensor(.5)
   cpu=(q,k,v,beta,ell,state,c);ref=tuple(x.double().requires_grad_() for x in cpu)
   expected=truth(*ref[:5],initial_state=ref[5],curvature=ref[6],group_size=32,output_final_state=True,cu_seqlens=bounds)
   xs=tuple(x.cuda().requires_grad_() for x in cpu);cu=None if bounds is None else bounds.cuda()
   cot=[.03*torch.randn(x.shape,device='cuda',dtype=torch.float32) for x in expected]
   reference_grads=torch.autograd.grad(expected,ref,[x.cpu().double() for x in cot])
   with _NoFP64Training():
    info={};actual=candidate.chunk_bf16(*xs[:5],initial_state=xs[5],curvature=xs[6],group_size=32,chunk_size=chunk,output_final_state=True,cu_seqlens=cu,telemetry=info)
    grads=torch.autograd.grad(actual,xs,cot)
    base=baseline.chunk_bf16(*xs[:5],initial_state=xs[5],curvature=xs[6],group_size=32,chunk_size=chunk,output_final_state=True,cu_seqlens=cu)
    base_grads=torch.autograd.grad(base,xs,cot)
    assert all(torch.equal(a,b) for a,b in zip((*actual,*grads),(*base,*base_grads))), 'Dead-store removal changed results'
   metrics=[]
   for index,(name,x,y) in enumerate(zip(['output','final','dq','dk','dv','dbeta','dell','ds0','dc'],(*actual,*grads),(*expected,*reference_grads))):
    a,b=x.detach().cpu().double(),y.detach();atol,rtol,budget=(.002,.02,.01) if index<2 else (.005,.03,.015)
    rms=float((a-b).square().mean().sqrt());limit=budget*max(atol,float(b.square().mean().sqrt()));bad=int((~torch.isclose(a,b,atol=atol,rtol=rtol)).sum());finite=bool(torch.isfinite(a).all())
    metrics.append(dict(source=name,bad=bad,rms=rms,limit=limit,finite=finite,passed=finite and bad==0 and rms<=limit))
   rows.append(dict(chunk=chunk,packed=packed,length=length,metrics=metrics,telemetry=info));(O/'progress.json').write_text(json.dumps({'rows':rows},indent=2));print('CHUNK',chunk,'PACKED',packed,[(m['source'],m['bad'],m['rms'],m['limit']) for m in metrics if not m['passed']],flush=True)
   assert all(m['finite'] for m in metrics)
finally:torch.empty,torch.empty_like=real_empty,real_empty_like
(O/'result.json').write_text(json.dumps(dict(status='FLEXIBLE_CHUNK_NUMERIC_SCREEN_COMPLETE',rows=rows,all_passed=all(m['passed'] for r in rows for m in r['metrics']),poison_checks=poison_checks,baseline_exact=True,scope='8dense/packed/tail cases, all4C, all9outputs/gradients exact vs same-source baseline and originalbudgets; checks proveP3/P4 uninitialized until interval_cache.'),indent=2))
