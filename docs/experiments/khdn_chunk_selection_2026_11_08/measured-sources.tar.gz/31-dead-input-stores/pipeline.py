from pathlib import Path
import hashlib,json,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent
R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
for name,digest in json.loads((D/'source-manifest.json').read_text())['files'].items():assert hashlib.sha256((D/'repo'/name).read_bytes()).hexdigest()==digest
out=O/'gate';out.mkdir()
env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-gate')
subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'check_dead.py')],env=env,check=True,timeout=900)
gate=json.loads((out/'result.json').read_text());assert gate['all_passed'] and gate['baseline_exact'] and len(gate['poison_checks'])==24
results={}
for name,variant in [('base','khdn_base'),('pair','khdn_combined'),('kda','kda_matched')]:
 out=O/name;out.mkdir();env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+name,FLEX_CHUNK='64',PAIRED_ARM=variant,SCREEN_VARIANT='kda_matched' if name=='kda' else 'khdn_c128',FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
 with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'model_screen.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 results[name]=json.loads((out/'result.json').read_text());print(name,results[name]['medians_ms'],flush=True)
weights=[json.loads((O/name/'qualification.json').read_text())['model']['initial_weights_sha256'] for name in ('base','pair')];assert weights[0]==weights[1]
(O/'result.json').write_text(json.dumps(dict(status='DEAD_STORE_GATE_AND_COST_COMPLETE',gate=gate,arms=results,scope='C1 removal only, original8gate +all9bitwise baseline agreement and24poison lifecycle checks, then samecardC64 full24 shortscreen base/candidate/KDA; generalnumericalqualification incomplete.'),indent=2))
