from pathlib import Path
import json,subprocess
D=Path(__file__).resolve().parent
R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09')
cfg=json.loads((R/'runtime.json').read_text())
subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'run_gate.py')],check=True,timeout=3600)
