from pathlib import Path
import sys,os,json,hashlib
D=Path(__file__).resolve().parent;O=D.parent
sys.path.insert(0,str(D/'repo'));os.chdir(D/'repo');os.environ['FLA_SOURCE_MANIFEST']=str(D/'source-manifest.json')
for n,h in json.loads((D/'source-manifest.json').read_text())['files'].items():assert hashlib.sha256((D/'repo'/n).read_bytes()).hexdigest()==h
import pytest
code=pytest.main(['tests/ops/test_key_gated_hyperbolic_bf16.py','-k','interval_preparation_tail_sources','-q','--junitxml='+str(O/'junit.xml')])
(O/'result.json').write_text(json.dumps(dict(status='PUBLIC_DEAD_STORE_GATE_COMPLETE',exit=code,scope='Public source integration, two fullC128tail/packed output/state/7VJP regressions, originalbudgets; otherknownfailuresunchanged')))
assert code==0
