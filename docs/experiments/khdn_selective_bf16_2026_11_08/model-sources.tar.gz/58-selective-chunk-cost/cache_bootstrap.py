from pathlib import Path
import sys,os,json,hashlib,tarfile
D=Path(__file__).resolve().parent
plan=json.loads((D/"model-plan.json").read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(*args):pass
assert not any(name in sys.modules for name in ('torch','triton','fla','benchmarks'))
assert sha(D / 'performance-priority-addendum.json') == plan['addendum_sha256']
assert sha(D / 'acceptance-contract.txt') == plan['contract_sha256']
cache = Path(os.environ['TRITON_CACHE_DIR'])
assert not list(cache.iterdir())
reference_cache = Path(plan['cache_ref'])
index = reference_cache / 'cache.json'
assert sha(index) == plan['cache_manifest_sha256']
want = {n: h for n, h in json.loads(index.read_bytes()).items() if n.endswith('.autotune.json')}
assert len(want) == 10
seen = set()
with tarfile.open(reference_cache / 'triton-cache.tar.gz', 'r|gz') as archive:
    for member in archive:
        path = Path(member.name)
        name = str(path.relative_to('triton')) if path.is_relative_to('triton') else ''
        if name not in want:
            continue
        assert member.isfile() and name not in seen and len(Path(name).parts) == 2 and '..' not in Path(name).parts
        value = archive.extractfile(member).read()
        assert hashlib.sha256(value).hexdigest() == want[name]
        dest = cache / name
        dest.parent.mkdir(exist_ok=True)
        dest.write_bytes(value)
        seen.add(name)
assert seen == set(want)
write('preimport.json', dict(shared_tuners=want, compiled_cache_copied=False))


if os.environ['SCREEN_VARIANT'] in ('khdn_c128','kda','kda_matched'):
    control_path=Path(plan['control_train_result'])
    assert sha(control_path)==plan['control_train_result_sha256']
    control=json.loads(control_path.read_bytes())
    assert control['status']=='CONTROL_FOUR_FINITE_UPDATES_COMPLETE'
    tuner_archive=control_path.parent/'tuners.tar.gz'
    assert sha(tuner_archive)==control['tuners']['archive_sha256']
    control_want=control['tuners']['files'];control_seen=set()
    with tarfile.open(tuner_archive,'r|gz') as stream:
        for item in stream:
            assert item.isfile() and item.name in control_want and len(Path(item.name).parts)==2 and '..' not in Path(item.name).parts
            assert item.name not in control_seen;control_seen.add(item.name)
            value=stream.extractfile(item).read();assert hashlib.sha256(value).hexdigest()==control_want[item.name]
            dest=cache/item.name;dest.parent.mkdir(exist_ok=True)
            if dest.exists():assert sha(dest)==control_want[item.name]
            dest.write_bytes(value)
    assert control_seen==set(control_want)
    want=control_want
    write('preimport.json',dict(shared_tuners=want,compiled_cache_copied=False,control_tuners_frozen=True))

