from pathlib import Path
import json,hashlib,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent;R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
a=json.loads((D/'admission.json').read_text());parent=Path(a['root']);strong=Path(a['strong_root'])
for root in (parent,strong):
 receipt=json.loads((root/'supervisor.json').read_text());assert receipt['terminal'] and receipt['reaped'] and receipt['group_drained'] and receipt['exit']==0 and not receipt['apps_after']
assert hashlib.sha256((parent/'result.json').read_bytes()).hexdigest()==a['result_sha256']
assert hashlib.sha256((D/'arms/selected/host.py').read_bytes()).hexdigest()==a['host_sha256']
assert hashlib.sha256((D/'arms/selected/kernels_selective.py').read_bytes()).hexdigest()==a['kernel_sha256']
assert hashlib.sha256((strong/'result.json').read_bytes()).hexdigest()==a['strong_result_sha256']
prior=json.loads((parent/'result.json').read_text());old=json.loads((strong/'result.json').read_text());assert old['all_passed'] and len(old['rows'])==16
assert prior['parts']['four_chunks']['result']['all_passed']
assert all(row['passed'] for part in ('original12','c0','boundary') for row in prior['parts'][part]['result']['rows'])
(O/'retained-gates.json').write_text(json.dumps(dict(selected=prior,historical=old),indent=2))
out=O/'inverse_control';out.mkdir();env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-control')
with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'control_gate.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
control=json.loads((out/'result.json').read_text());control_pass=all(row['passed'] for row in control['rows'])
arms=[('c64','selected',64)]+([('c64_i3','inverse3',64)] if control_pass else [])+[('c128','selected',128),('kda','selected',64)]
cost={}
for name,precision,chunk in arms:
 out=O/name;out.mkdir();env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+name,PRECISION_ARM=precision,FLEX_CHUNK=str(chunk),PAIRED_ARM='kda_matched' if name=='kda' else 'khdn_combined',SCREEN_VARIANT='kda_matched' if name=='kda' else 'khdn_c128',FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
 with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'model_screen.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 cost[name]=json.loads((out/'result.json').read_text());print(name,cost[name]['medians_ms'],flush=True)
weights=[json.loads((O/name/'qualification.json').read_text())['model']['initial_weights_sha256'] for name,_,_ in arms if name!='kda'];assert len(set(weights))==1
(O/'result.json').write_text(json.dumps(dict(status='SELECTIVE_CHUNK_COST_COMPLETE',inverse_control=control,control_pass=control_pass,arms=cost,scope='Selected56andhistorical57gatesPASS; originalC64I3controlqualifiesmatchedinverse comparison ifpassed. 2warm3steady full24, notformaltraining/quality/DDPqualification.'),indent=2))
