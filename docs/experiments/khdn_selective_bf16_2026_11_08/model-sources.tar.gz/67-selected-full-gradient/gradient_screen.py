"""Selected C64 full-model initial gradients; no optimizer or timing acceptance."""
from pathlib import Path
import collections
import gc
import importlib
import importlib.util
import json
import os
import statistics
import sys

D = Path(__file__).resolve().parent
sys.path[:0] = [str(D/'repo'),str(D/'candidate'),str(D)]
os.chdir(D/'repo')
os.environ['FLA_SOURCE_MANIFEST'] = str(D/'source-manifest.json')
os.environ['SCREEN_VARIANT'] = 'khdn_c128'
import cache_bootstrap as boot
import torch
from triton.runtime.autotuner import Autotuner
from benchmarks import benchmark_hyperbolic_training as b, hyperbolic_training_distributed as h
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training

O = Path(os.environ['BF16_PROBE_OUT'])
variant = os.environ['SCREEN_VARIANT']
assert variant in ('khdn_c128', 'kda_matched')
torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32 = False

def refuse(*args, **kwargs):
    raise RuntimeError('Unfrozen shared-kernel tuning requested')

Autotuner._bench = refuse
arguments = list(boot.plan['arguments'])
arguments[arguments.index('--chunk-size')+1] = '128'
arguments[arguments.index('--khdn-precision-policy')+1] = 'bf16'
args = b.parse_arguments(arguments)
# Match the existing private full-model C64 screen; public CLI integration remains pending.
args.chunk_size = 64
args.seed, args.data_seed, args.khdn_precision_policy = 101, 1009, 'bf16'
method = 'khdn_no_carry' if variant == 'khdn_c128' else 'kda'
args.methods = [method]
counts = collections.Counter()
resources = {}
eligibility_rows = []

from fla.ops.key_gated_hyperbolic_delta_rule import chunk128 as live
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
candidate=load('combined_gradient_host',D/'candidate/host.py')
live.chunk_bf16=candidate.chunk_bf16
from fla.ops.key_gated_hyperbolic_delta_rule import bf16 as small_entry
small_entry.chunk_bf16=candidate.chunk_bf16
if variant == 'khdn_c128':
    original_launch = candidate.launch

    def observed(kernel, grid, values, telemetry, **kwargs):
        result = original_launch(kernel, grid, values, telemetry, **kwargs)
        counts[kernel.__name__] += 1
        if kernel.__name__ == "diagonal_eligibility":
            eligibility_rows.append(dict(eligible=int(values[4].sum().item()), total=values[4].numel()))
        resources[kernel.__name__] = dict(registers=result.n_regs, spills=result.n_spills,
                                          shared=result.metadata.shared, grid=list(grid),
                                          wgmma=result.asm['ptx'].count('wgmma.mma_async'),
                                          mma_sync=result.asm['ptx'].count('mma.sync'),
                                          local_load_instructions=result.asm['ptx'].count('ld.local'))
        return result

    candidate.launch = observed
    from fla.ops.key_gated_hyperbolic_delta_rule import fused_prepare as native_preprocessing
    preprocessing=load('combined_gradient_preprocessing',D/'candidate/preprocessing.py')
    native_preprocessing.fused_preprocessing=preprocessing.fused_preprocessing
    prepare_launch = preprocessing.launch
    def observed_prepare(kernel, grid, values, telemetry=None, **kwargs):
        result = prepare_launch(kernel, grid, values, telemetry, **kwargs)
        counts[kernel.__name__] += 1
        return result
    preprocessing.launch = observed_prepare
    preprocessing_binding = dict(route='explicit_operator_and_preprocessing_overrides',runtime_layer_patch=False,files={str(p.relative_to(D)):boot.sha(p) for p in (D/'candidate').glob('*.py')})

def write(name, value):
    (O / name).write_text(json.dumps(value, indent=2, allow_nan=False))

with h.Runtime(args) as runtime, b.environment(b.method_spec(method)['environment']):
    assert runtime.world_size == 1
    model, info = b.build_model(args, b.method_spec(method), small=False)
    layers = [m for name, m in model.named_modules() if name in boot.plan['layer_names']]
    assert len(layers) == 24 and all(layer.chunk_size == 64 for layer in layers)
    assert model.config.chunk_size == 64
    assert sum(p.numel() for p in model.parameters()) == 1412912512
    assert len(list(model.parameters())) == 459
    import math
    import hashlib
    from torch.nn import functional as F

    def sha_file(path):
        with Path(path).open('rb') as stream:
            return hashlib.file_digest(stream, 'sha256').hexdigest()

    from benchmarks.hyperbolic_benchmark_utils import validated_source_snapshot
    identity = validated_source_snapshot(D/'repo', D/'source-manifest.json')
    assert sha_file(D/'repo/fla/models/key_gated_hyperbolic_deltanet/modeling_key_gated_hyperbolic_deltanet.py') == '8dc0b161e4f8d9ee1266d459daef41228ca2e5573d08ed65d3079ccf86bd74eb'
    reuse = json.loads((D/'reference-reuse.json').read_text())
    refroot = Path(reuse['root'])
    for name, digest in reuse['files'].items():
        assert sha_file(refroot/name) == digest
    reference = json.loads((refroot/'strict_reference-result.json').read_text())
    assert reference['status'] == 'ZERO_UPDATE_ARM_COMPLETE'
    assert info['initial_weights_sha256'] == reference['model']['initial_weights_sha256']
    ac = json.loads(json.dumps(model.config.to_dict()))
    rc = json.loads(json.dumps(reference['model']['configuration']))
    for cfg in (ac, rc):
        cfg.pop('precision_policy'); cfg.pop('chunk_size')
    assert ac == rc
    params = dict(model.named_parameters())
    assert list(params) == boot.plan['names'] and len(params) == 459
    assert sum(p.numel() for p in params.values()) == 1412912512
    rng = {key:hashlib.sha256(value.numpy().tobytes()).hexdigest()
           for key,value in [('cpu',torch.get_rng_state()),('cuda',torch.cuda.get_rng_state().cpu())]}
    assert rng == reference['initial_rng']
    batch_cpu = h.make_batch(args, 0)
    assert batch_cpu.sha256 == reuse['batch_sha256'] and batch_cpu.valid_labels == 16376
    torch.save(batch_cpu.inputs, O/'batch.pt')
    batch = batch_cpu.to('cuda')
    with _NoFP64Training(), h.observe_key_gates(model, method) as gates:
        with torch.autocast('cuda', dtype=torch.bfloat16):
            output = model(**batch.inputs, use_cache=False, num_items_in_batch=batch.valid_labels)
        loss = output.loss
        with torch.no_grad(), torch.autocast('cuda', enabled=False):
            targets = torch.cat((batch.inputs['labels'][:,1:], torch.full_like(batch.inputs['labels'][:,:1], -100)), 1)
            evaluation = F.cross_entropy(output.logits.detach().float().reshape(-1,32000), targets.reshape(-1),
                                         ignore_index=-100, reduction='sum') / batch.valid_labels
        assert torch.isfinite(loss) and torch.isfinite(evaluation)
        loss.backward()
        torch.cuda.synchronize()
    assert counts['state_fwd_kernel'] == 48 and counts['state_bwd_kernel'] == 24
    assert counts['preprocessing_fwd']==48 and counts['preprocessing_bwd']==24
    assert resources['state_fwd_kernel']['grid'] == [512] and resources['output_fwd_kernel']['grid'] == [16384]
    assert len(gates) == 24 and all(x['curvature']==1 and x['gate_projection_trainable']
                                  and x['log_decay_min']<x['log_decay_max']<0 for x in gates.values())
    report = dict(status='CAPTURING_INITIAL_GRADIENTS', model=info, execution_configuration=model.config.to_dict(),
                  batch_sha256=batch_cpu.sha256, initial_rng=rng, physical_optimizer_updates=0,
                  loss=float(loss.detach()), evaluation_CE_fp32=float(evaluation),
                  reference_CE_fp32=reference['evaluation_CE_fp32'],
                  counts=dict(counts), resources=resources, gates=gates, preprocessing_binding=preprocessing_binding,
                  source_validation_fallbacks=getattr(candidate,'_source_validation_fallbacks',None),
                  reference_reuse=reuse, reference_identity=identity, gradients={})
    write('progress.json', report)
    del output, loss, evaluation, targets, batch
    folder = O/'gradients'; folder.mkdir()
    sums = [[],[],[],[]]
    old_bad = 0
    for index,(name,param) in enumerate(params.items()):
        x = param.grad.detach().contiguous().cpu()
        assert x.dtype == torch.float32 and torch.isfinite(x).all()
        ref = reference['gradients'][name]
        filename = f'{index:03d}.pt'
        assert ref['file'] == filename and ref['shape'] == list(x.shape)
        path = folder/filename; torch.save(x,path)
        reference_path = refroot/'strict_reference/gradients'/filename
        assert sha_file(reference_path) == ref['sha256']
        y = torch.load(reference_path,weights_only=True,map_location='cpu',mmap=True)
        assert y.dtype == torch.float32 and y.shape == x.shape and torch.isfinite(y).all()
        local = [[],[],[],[]]; bad = 0
        for u,v in zip(x.reshape(-1).split(1048576),y.reshape(-1).split(1048576)):
            # Explicit untimed CPU error analysis; no GPU/reference execution or optimizer update.
            aa,bb = u.double(),v.double()
            values = [(aa-bb).square().sum(),aa.square().sum(),bb.square().sum(),(aa*bb).sum()]
            for dst,value in zip(local,values):dst.append(float(value))
            bad += int((~torch.isclose(u,v,atol=.002,rtol=.02)).sum())
        totals = [math.fsum(values) for values in local]
        for dst,value in zip(sums,totals):dst.append(value)
        old_bad += bad
        report['gradients'][name] = dict(file=filename,sha256=sha_file(path),reference_sha256=ref['sha256'],
                                        shape=list(x.shape),elements=x.numel(),old_budget_bad=bad,
                                        **dict(zip(['error_squared','actual_squared','reference_squared','dot'],totals)))
        param.grad = None
        del x,y
        if index%64==0:
            report['captured_parameters']=index+1;write('progress.json',report)
            print('CAPTURED',index+1,flush=True)
    error2,actual2,reference2,dot = [math.fsum(values) for values in sums]
    cosine = dot/math.sqrt(actual2*reference2)
    ratio = math.sqrt(actual2/reference2)
    assert b.weight_digest(model.cpu()) == info['initial_weights_sha256']
    report.update(status='SELECTED_C64_INITIAL_GRADIENT_COMPLETE',captured_parameters=459,
                  gradient_cosine=cosine,gradient_norm_ratio=ratio,gradient_relative_L2=math.sqrt(error2/reference2),
                  initial_gradient_gate_passed=cosine>=.99 and .9<=ratio<=1.1,
                  old_budget_bad=old_bad,initial_PPL_difference_percent=100*math.expm1(report['evaluation_CE_fp32']-reference['evaluation_CE_fp32']),
                  weights_unchanged=True,
                  scope='One full24 selected C64 initial gradient screen against saved strict reference; current bounded operator gates56/57 retained. Experimental entry overrides explicit, not production integration. '
                        'ExplicitCPUFP64analysis only; candidate BF16/FP32. No optimizer, long quality, recovery or scaling acceptance.')
    write('result.json',report)
    print('FULL_GRADIENT',cosine,ratio,report['initial_gradient_gate_passed'],flush=True)
