from pathlib import Path
import json,hashlib,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent;R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
a=json.loads((D/'admission.json').read_text());parent=Path(a['root']);strong=Path(a['strong_root'])
for root in (parent,strong):
 receipt=json.loads((root/'supervisor.json').read_text());assert receipt['terminal'] and receipt['reaped'] and receipt['group_drained'] and receipt['exit']==0 and not receipt['apps_after']
assert hashlib.sha256((parent/'result.json').read_bytes()).hexdigest()==a['result_sha256']
assert hashlib.sha256((D/'candidate/host.py').read_bytes()).hexdigest()==a['host_sha256']
assert hashlib.sha256((D/'candidate/kernels_selective.py').read_bytes()).hexdigest()==a['kernel_sha256']
assert hashlib.sha256((strong/'result.json').read_bytes()).hexdigest()==a['strong_result_sha256']
prior=json.loads((parent/'result.json').read_text());old=json.loads((strong/'result.json').read_text());assert old['all_passed'] and len(old['rows'])==16
assert prior['parts']['four_chunks']['result']['all_passed']
assert all(row['passed'] for part in ('original12','c0','boundary') for row in prior['parts'][part]['result']['rows'])
(O/'retained-gates.json').write_text(json.dumps(dict(selected=prior,historical=old),indent=2))
out=O/'grad';out.mkdir()
env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-grad',SCREEN_VARIANT='khdn_c128',FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'gradient_screen.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3300)
result=json.loads((out/'result.json').read_text())
(O/'result.json').write_text(json.dumps(dict(status='SELECTED_C64_FULL_GRADIENT_SCREEN_COMPLETE',result=result),indent=2))
print('FULL_GRADIENT',result['gradient_cosine'],result['gradient_norm_ratio'],result['initial_gradient_gate_passed'],flush=True)
