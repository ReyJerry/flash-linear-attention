"""Original seed42/T129 fixtures, fixed cotangents, independent precision ablations.

This diagnostic preserves failed budgets and never runs a FP64 training candidate.
CPU FP64 is used explicitly and only for untimed canonical truth and error metrics.
"""
from pathlib import Path
import hashlib
import importlib
import json
import os
import sys
import traceback

D = Path(__file__).resolve().parent
O = Path(os.environ['BF16_PROBE_OUT'])
sys.path[:0] = [str(D/'repo'), str(D/'repo/tests/ops'), str(D/'variants')]
os.environ['FLA_SOURCE_MANIFEST'] = str(D/'source-manifest.json')
for name, digest in json.loads((D/'source-manifest.json').read_text())['files'].items():
    assert hashlib.sha256((D/'repo'/name).read_bytes()).hexdigest() == digest

import torch
from test_key_gated_hyperbolic_delta_rule import make_case, ops
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
from fla.ops.key_gated_hyperbolic_delta_rule import bf16, chunk128
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth

torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32 = False
hosts = {name: importlib.import_module('host_'+name) for name in ('selective',)}
published128, published_small = chunk128.chunk_bf16, bf16.chunk_bf16
real_empty, real_empty_like = torch.empty, torch.empty_like

def poison(function):
    def allocate(*args, **kwargs):
        x = function(*args, **kwargs)
        if x.is_cuda and x.is_floating_point():
            with torch.no_grad():
                x.fill_(float('nan'))
        return x
    return allocate

torch.empty, torch.empty_like = poison(real_empty), poison(real_empty_like)
rows = []
images = {}
for name, host in hosts.items():
    original = host.launch
    def observed(kernel, grid, args, telemetry, _original=original, _name=name, **kwargs):
        compiled = _original(kernel, grid, args, telemetry, **kwargs)
        digest = hashlib.sha256(compiled.asm['ttir'].encode()).hexdigest()
        if digest not in images:
            folder = O/'images'; folder.mkdir(exist_ok=True)
            (folder/(digest+'.ttir')).write_text(compiled.asm['ttir'])
            (folder/(digest+'.ptx')).write_text(compiled.asm['ptx'])
            images[digest] = dict(variant=_name, kernel=kernel.__name__, registers=compiled.n_regs,
                                  spills=compiled.n_spills, grid=list(grid))
        return compiled
    host.launch = observed

def invoke(source, cu, chunk, telemetry):
    return ops.chunk_key_gated_hyperbolic_delta_rule(
        *source[:5], curvature=source[6], initial_state=source[5], output_final_state=True,
        cu_seqlens=cu, group_size=32, chunk_size=chunk, carry_mode='no_carry',
        precision_policy='bf16', telemetry=telemetry)

def metric(name, actual, expected, backward):
    a, b = actual.detach().cpu().double(), expected.detach().cpu().double()
    atol, rtol, budget = (.005, .03, .015) if backward else (.002, .02, .01)
    error = a-b
    rms = float(error.square().mean().sqrt())
    reference_rms = float(b.square().mean().sqrt())
    limit = budget*max(atol, reference_rms)
    bad = int((~torch.isclose(a,b,atol=atol,rtol=rtol)).sum())
    flat = int(error.abs().reshape(-1).argmax())
    coord = []
    for length in reversed(a.shape):
        coord.append(flat % length); flat //= length
    finite = bool(torch.isfinite(a).all())
    return dict(source=name, shape=list(a.shape), elements=a.numel(), finite=finite,
                max_abs=float(error.abs().max()), max_coordinate=list(reversed(coord)),
                rms=rms, reference_rms=reference_rms, rms_limit=limit,
                relative_l2=float(error.norm()/b.norm()) if float(b.norm()) else None,
                atol=atol, rtol=rtol, rms_budget=budget, elementwise_bad=bad,
                sign_disagreements=int(((a*b)<0).sum()), passed=finite and bad==0 and rms<=limit)

try:
    for mode in ('joint',):
        for packed in (False,True):
            for dtype in (torch.float32,torch.bfloat16):
                case = f'{mode}-{int(packed)}-{str(dtype).split(".")[-1]}'
                parent = Path('/mnt/cephfs/akseli/hyperbolic-validation/khdn-numeric28-cost-b2be7592e459')
                parent_result = json.loads((parent/'result.json').read_text())
                parent_row = next(x for x in parent_result['rows'] if x['case']==case and x['variant']=='base' and x['chunk']==64)
                saved_path = parent/'fixtures'/(case+'.pt')
                assert hashlib.sha256(saved_path.read_bytes()).hexdigest()==parent_row['fixture_sha256']
                saved = torch.load(saved_path, map_location='cpu', weights_only=True)
                source = tuple(x.cuda().requires_grad_() for x in saved['source'])
                source = (*source[:6], torch.zeros_like(source[6], requires_grad=True))
                cu = None if saved['cu'] is None else saved['cu'].cuda()
                cot = [x.cuda() for x in saved['cot']]
                if mode == 'output': cot[1].zero_()
                if mode == 'state': cot[0].zero_()
                case = f'{mode}-{int(packed)}-{str(dtype).split(".")[-1]}'
                folder = O/'fixtures';folder.mkdir(exist_ok=True)
                fixture = folder/(case+'.pt')
                torch.save(dict(source=[x.detach().cpu() for x in source],
                                cot=[x.cpu() for x in cot], cu=None if cu is None else cu.cpu()),fixture)
                reference = tuple(x.detach().cpu().double().requires_grad_() for x in source)
                expected = truth(*reference[:5], curvature=reference[6], initial_state=reference[5],
                                 output_final_state=True, cu_seqlens=None if cu is None else cu.cpu(),group_size=32)
                reference_grads = torch.autograd.grad(expected, reference, [x.cpu().double() for x in cot])
                norm = source[1].detach().float().square().sum(-1)
                margin = norm[...,None] - source[6].detach()/32 * source[2].detach().float().reshape(*norm.shape,4,32).square().sum(-1)
                domain = dict(min_key_norm=float(norm.min()), min_margin=float(margin.min()),
                              beta_zero=int((source[3]==0).sum()),beta_one=int((source[3]==1).sum()))
                for variant, chunk in [(v,c) for v in hosts for c in (64,128)]:
                    info = {}
                    row = dict(case=case,variant=variant,chunk=chunk,seed=42,length=129,domain=domain,curvature_override=0,parent_fixture_sha256=parent_row['fixture_sha256'],
                               fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest())
                    chunk128.chunk_bf16 = published128 if variant=='published' else hosts[variant].chunk_bf16
                    bf16.chunk_bf16 = published_small if variant=='published' else hosts[variant].chunk_bf16
                    rng = torch.cuda.get_rng_state()
                    try:
                        with _NoFP64Training():
                            actual = invoke(source,cu,chunk,info)
                            assert torch.equal(rng,torch.cuda.get_rng_state()), 'Unexpected candidate RNG consumption'
                            gradients = torch.autograd.grad(actual,source,cot,retain_graph=True)
                            repeated = torch.autograd.grad(actual,source,cot)
                            torch.cuda.synchronize()
                        row['repeat_exact'] = all(torch.equal(a,b) for a,b in zip(gradients,repeated))
                        row['metrics'] = [metric(n,a,b,i>=2) for i,(n,a,b) in enumerate(zip(
                            ('output','final','dq','dk','dv','dbeta','dell','dS0','dc'),
                            (*actual,*gradients),(*expected,*reference_grads)))]
                        row['passed'] = row['repeat_exact'] and all(x['passed'] for x in row['metrics'])
                    except Exception as error:
                        row.update(passed=False,error=repr(error),traceback=traceback.format_exc())
                        # CUDA execution faults invalidate a context; do not continue after them.
                        if 'CUDA error' in str(error):
                            rows.append(row);(O/'progress.json').write_text(json.dumps(rows,indent=2));raise
                    row['telemetry'] = info
                    rows.append(row)
                    (O/'progress.json').write_text(json.dumps(rows,indent=2,allow_nan=False))
                    print(case,variant,chunk,row['passed'],[(x['source'],x['elementwise_bad'],x['rms'],x['rms_limit']) for x in row.get('metrics',[]) if not x['passed']],row.get('error',''),flush=True)
    (O/'result.json').write_text(json.dumps(dict(status='DIAGNOSTICS_COMPLETE_NOT_AUTOMATIC_QUALIFICATION',rows=rows,images=images,
        scope='Reuses original12 archived fixtures exactly; C64/C128 mass-system preconditioned feedback with FP32 diagonal vectors and BF16 matrices; BF16 dots unchanged. Compare archived base64; diagnosis not production qualification.'),indent=2,allow_nan=False))
finally:
    torch.empty, torch.empty_like = real_empty, real_empty_like
    chunk128.chunk_bf16, bf16.chunk_bf16 = published128, published_small
