from pathlib import Path
import json,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent;R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text());results={}
for name,script in [('four_chunks','check_sizes.py'),('original12','diagnose.py'),('c0','check_c0.py'),('boundary','boundary.py')]:
 out=O/name;out.mkdir();env=dict(os.environ,BF16_PROBE_OUT=str(out),KHDN_RUN_ID=os.environ['KHDN_RUN_ID']+'-'+name)
 cmd=[cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/script)]
 if name=='four_chunks':cmd=['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','99']+cmd
 with (out/'process.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 results[name]=dict(exit=r.returncode,result=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else None)
 print(name,'exit',r.returncode,flush=True)
 if r.returncode!=0:break
(O/'result.json').write_text(json.dumps(dict(status='SELECTIVE_PRECISION_COMBINED_GATE_COMPLETE',parts=results,scope='Combination54tail3+55querycopyremoval+53C128inversepreparation3; unchangedoriginalbudgets,fourchunkmemcheck/original12/c0/B3; notproductionqualification.'),indent=2))
