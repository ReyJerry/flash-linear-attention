from pathlib import Path
import importlib.util,json,os,sys,hashlib
D=Path(__file__).resolve().parent;O=D.parent
sys.path[:0]=[str(D/'repo'),str(D/'candidate')]
os.environ['FLA_SOURCE_MANIFEST']=str(D/'source-manifest.json')
import torch
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
spec=importlib.util.spec_from_file_location('historical_gate_candidate',D/'candidate/host.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
cases=[(257,.5,128,False,'none',None,torch.float32,1.),(129,0.,128,False,'none',None,torch.float32,1.),
       (129,.5,64,False,'first',None,torch.float32,.7),(129,.5,128,False,'internal',None,torch.float32,1.),
       (129,.5,64,False,'none','mixed',torch.float32,1.),(257,.5,128,True,'none',None,torch.bfloat16,1.),
       (129,.5,32,False,'none',None,torch.float32,1.),(257,.5,128,False,'none','distinct',torch.bfloat16,1.)]

rows=[]
real_empty,real_empty_like=torch.empty,torch.empty_like
def poison(function):
 def allocate(*args,**kwargs):
  value=function(*args,**kwargs)
  if value.is_cuda and value.is_floating_point():
   with torch.no_grad():value.fill_(float('nan'))
  return value
 return allocate
torch.empty,torch.empty_like=poison(real_empty),poison(real_empty_like)
try:
 for index,(length,curvature,vd,packed,strong,levels,dtype,kscale) in enumerate(cases):
  torch.manual_seed(8013+index)
  shape=(1,length,1,128)
  q=torch.nn.functional.normalize(torch.randn(shape),dim=-1).to(dtype)
  k=(torch.nn.functional.normalize(torch.randn(shape),dim=-1)*kscale).to(dtype)
  v=.025*torch.randn(1,length,1,vd)
  if levels=='mixed':v[...,:32]=.3;v[...,32:]=.7
  if levels=='distinct':v*=torch.arange(1,vd//32+1).repeat_interleave(32)
  v=v.to(dtype);beta=torch.sigmoid(torch.randn(1,length,1));beta[:,0]=0;beta[:,1]=1
  ell=-.02-.08*torch.rand(shape)
  if strong=='first':ell[:,0]=-1e8;ell[:,1]=-1
  if strong=='internal':ell[:,7]=-1e8;ell[:,8]=-1
  bounds=torch.tensor([0,0,129,length,length],dtype=torch.int64) if packed else None
  state=.001*torch.randn(4 if packed else 1,1,128,vd);curve=torch.tensor(curvature)
  cpu=(q,k,v,beta,ell,state,curve);ref=tuple(x.double().requires_grad_() for x in cpu)
  expected=truth(*ref[:5],initial_state=ref[5],curvature=ref[6],group_size=32,output_final_state=True,cu_seqlens=bounds)
  xs=tuple(x.cuda().requires_grad_() for x in cpu);cu=None if bounds is None else bounds.cuda()
  cot=[.03*torch.randn(x.shape,device='cuda',dtype=(dtype if i==0 else torch.float32)) for i,x in enumerate(expected)]
  ref_grad=torch.autograd.grad(expected,ref,[x.cpu().double() for x in cot])

  folder=O/'fixtures';folder.mkdir(exist_ok=True);fixture=folder/(str(index)+'.pt')
  torch.save(dict(source=[x.detach().cpu() for x in xs],cot=[x.cpu() for x in cot],bounds=bounds),fixture)
  for chunk in (64,128):
   with _NoFP64Training():
    info={};out=candidate.chunk_bf16(*xs[:5],initial_state=xs[5],curvature=xs[6],group_size=32,chunk_size=chunk,output_final_state=True,cu_seqlens=cu,telemetry=info)
    grads=torch.autograd.grad(out,xs,cot,retain_graph=True);repeat=torch.autograd.grad(out,xs,cot)
   metrics=[]
   for i,(name,x,y) in enumerate(zip(['output','final','dq','dk','dv','dbeta','dell','ds0','dc'],(*out,*grads),(*expected,*ref_grad))):
    a,b=x.detach().cpu().double(),y.detach();atol,rtol,budget=(.002,.02,.01) if i<2 else (.005,.03,.015)
    rms=float((a-b).square().mean().sqrt());limit=budget*max(float(b.square().mean().sqrt()),atol);bad=int((~torch.isclose(a,b,atol=atol,rtol=rtol)).sum());finite=bool(torch.isfinite(a).all())
    metrics.append(dict(source=name,bad=bad,rms=rms,limit=limit,finite=finite,passed=finite and bad==0 and rms<=limit))
   row=dict(case=index,chunk=chunk,seed=8013+index,length=length,curvature=curvature,vd=vd,packed=packed,strong=strong,levels=levels,dtype=str(dtype),kscale=kscale,metrics=metrics,repeat_exact=all(torch.equal(a,b) for a,b in zip(grads,repeat)),fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest())
   rows.append(row);(O/'progress.json').write_text(json.dumps(rows,indent=2));print('CASE',index,chunk,[(m['source'],m['bad'],m['rms'],m['limit']) for m in metrics if not m['passed']],flush=True)
finally:torch.empty,torch.empty_like=real_empty,real_empty_like
(O/'result.json').write_text(json.dumps(dict(status='HISTORICAL_EIGHT_CASE_REQUALIFICATION_COMPLETE',rows=rows,all_passed=all(row['repeat_exact'] and all(m['passed'] for m in row['metrics']) for row in rows),scope='Exact21casegenerationandcotangentprotocol; bothchunksreuseinputs; originalbeta/cgradientfailuresnotwaived. No modelqualification.'),indent=2))
