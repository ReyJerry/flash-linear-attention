from pathlib import Path
import json,subprocess
D=Path(__file__).resolve().parent
R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09')
cfg=json.loads((R/'runtime.json').read_text())
p=Path('/mnt/cephfs/akseli/hyperbolic-validation/khdn-numeric28-cost-b2be7592e459')
import hashlib
assert hashlib.sha256((p/'result.json').read_bytes()).hexdigest()=='ecdaa4005e4c0d6167826ad6c58e9131d52224914314e27411ff270d16dd964e'
r=json.loads((p/'supervisor.json').read_text());assert r['terminal'] and r['reaped'] and r['group_drained'] and r['exit']==0
subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'gate.py')],check=True,timeout=3600)
