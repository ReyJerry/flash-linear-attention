"""Selected candidate boundary, alias, graph and stream qualification."""
from pathlib import Path
import importlib.util
import json
import os
import sys

D = Path(__file__).resolve().parent
O = Path(os.environ['BF16_PROBE_OUT'])
sys.path[:0] = [str(D / 'repo'), str(D / 'candidate')]
import torch
from benchmarks.hyperbolic_benchmark_utils import _NoFP64Training
from fla.ops.key_gated_hyperbolic_delta_rule.naive import naive_recurrent_key_gated_hyperbolic_delta_rule as truth

spec = importlib.util.spec_from_file_location('selected_core', D / 'candidate/host.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32 = False
rows = []


def metric(a, b, backward):
    a, b = a.detach().cpu().double(), b.detach().cpu().double()
    atol, rtol, budget = (.005, .03, .015) if backward else (.002, .02, .01)
    finite = bool(torch.isfinite(a).all() and torch.isfinite(b).all())
    bad = int((~torch.isclose(a, b, atol=atol, rtol=rtol)).sum())
    rms = float((a - b).square().mean().sqrt())
    limit = budget * max(atol, float(b.square().mean().sqrt()))
    return dict(finite=finite, bad=bad, rms=rms, limit=limit,
                passed=finite and bad == 0 and rms <= limit)


def inputs(length, packed, dtype, mode):
    torch.manual_seed(16000 + length + int(packed))
    shape = (1, length, 1, 128)
    q = torch.nn.functional.normalize(torch.randn(shape), dim=-1).to(dtype)
    k = torch.nn.functional.normalize(torch.randn(shape), dim=-1).to(dtype)
    v = (.025 * torch.randn(shape)).to(dtype)
    beta = torch.sigmoid(torch.randn(1, length, 1)); beta[:, 0] = 0; beta[:, 1] = 1
    ell = -.02 - .08 * torch.rand(shape)
    cu = torch.tensor([0, 0, 1, length, length], dtype=torch.int64) if packed else None
    state = .001 * torch.randn(4 if packed else 1, 1, 128, 128)
    curvature = torch.tensor(0. if length in (64, 128) else .5)
    raw = (q, k, v, beta, ell, state, curvature)
    if mode in ('alias', 'nonleaf'):
        raw = (q, v, beta, ell, state, curvature)
    return raw, cu


def sources(leaves, mode):
    if mode == 'alias':
        return (leaves[0], leaves[0], *leaves[1:])
    if mode == 'nonleaf':
        return (leaves[0] * 1.01, leaves[0] * .99, *leaves[1:])
    return leaves


def run(length, packed, dtype, mode):
    raw, bounds = inputs(length, packed, dtype, mode)
    reference_leaves = tuple(x.double().requires_grad_() for x in raw)
    ref = sources(reference_leaves, mode)
    expected = truth(*ref[:5], initial_state=ref[5], curvature=ref[6],
                     output_final_state=True, cu_seqlens=bounds, group_size=32)
    # One cotangent draw shared by both execution chunks.
    cot = tuple(.03 * torch.randn(x.shape) for x in expected)
    reference_grads = torch.autograd.grad(expected, reference_leaves, tuple(x.double() for x in cot))
    for chunk in (64, 128):
        leaves = tuple(x.cuda().requires_grad_() for x in raw)
        xs = sources(leaves, mode)
        cu = None if bounds is None else bounds.cuda()
        dcot = tuple(x.cuda() for x in cot)
        info = {}

        def evaluate():
            actual = core.chunk_bf16(*xs[:5], initial_state=xs[5], curvature=xs[6],
                                    cu_seqlens=cu, group_size=32, chunk_size=chunk,
                                    output_final_state=True, telemetry=info)
            grads = torch.autograd.grad(actual, leaves, dcot, retain_graph=True)
            again = torch.autograd.grad(actual, leaves, dcot, retain_graph=True)
            assert all(torch.equal(a, b) for a, b in zip(grads, again))
            return (*actual, *grads)

        with _NoFP64Training():
            observed = evaluate()
            same_stream = None
            if mode != 'independent':
                other = torch.cuda.Stream()
                other.wait_stream(torch.cuda.current_stream())
                with torch.cuda.stream(other):
                    alternate = evaluate()
                torch.cuda.current_stream().wait_stream(other)
                same_stream = all(torch.equal(a, b) for a, b in zip(observed, alternate))
                assert same_stream
        measures = [metric(a, b, i >= 2) for i, (a, b) in enumerate(
            zip(observed, (*expected, *reference_grads)))]
        row = dict(length=length, packed=packed, dtype=str(dtype), mode=mode,
                   chunk=chunk, metrics=measures, repeat_exact=True,
                   cross_stream_exact=same_stream, telemetry=info,
                   passed=all(x['passed'] for x in measures))
        rows.append(row)
        (O / 'progress.json').write_text(json.dumps(rows, indent=2))
        print(length, packed, str(dtype), mode, chunk, row['passed'], flush=True)


real_empty, real_empty_like = torch.empty, torch.empty_like


def poison(function):
    def call(*args, **kwargs):
        result = function(*args, **kwargs)
        if result.is_cuda and result.is_floating_point():
            with torch.no_grad():
                result.fill_(float('nan'))
        return result
    return call


torch.empty, torch.empty_like = poison(real_empty), poison(real_empty_like)
try:
    for length in (63, 64, 65, 127, 128, 129):
        for packed in (False, True):
            for dtype in (torch.float32, torch.bfloat16):
                run(length, packed, dtype, 'independent')
    for mode in ('alias', 'nonleaf'):
        for dtype in (torch.float32, torch.bfloat16):
            run(129, True, dtype, mode)
finally:
    torch.empty, torch.empty_like = real_empty, real_empty_like
(O / 'result.json').write_text(json.dumps(dict(
    status='SELECTED_BOUNDARY_ALIAS_COMPLETE', rows=rows,
    all_passed=all(r['passed'] for r in rows),
    scope='48 boundary cases plus8 alias/nonleaf cases with cross-stream replay. '
          'Unchanged BF16 budgets; explicit untimed CPU FP64 truth only. '
          'Not full model/cache/distributed qualification.'), indent=2))
