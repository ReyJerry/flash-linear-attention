from pathlib import Path
import json,os,subprocess
D=Path(__file__).resolve().parent;O=D.parent;R=Path('/tmp/khdn-public-bf16-6d1e9392b98afb09');cfg=json.loads((R/'runtime.json').read_text())
out=O/'check';out.mkdir()
env=dict(os.environ,BF16_PROBE_OUT=str(out),FLA_SOURCE_MANIFEST=str(D/'source-manifest.json'))
with (out/'process.log').open('w') as log:subprocess.run([cfg['python'],'-I',str(R/'run_project.py'),'-B',str(D/'check.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3300)
result=json.loads((out/'result.json').read_text());(O/'result.json').write_text(json.dumps(result,indent=2));print('BOUNDARIES',len(result['rows']),result['all_passed'],flush=True)
