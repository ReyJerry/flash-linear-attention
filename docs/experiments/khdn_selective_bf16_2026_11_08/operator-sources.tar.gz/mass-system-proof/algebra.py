"""Untimed CPU proof of mass-system preconditioning and its scalar source VJP."""
from pathlib import Path
import json
import torch

torch.set_num_threads(2)
torch.manual_seed(42)

def common(n,beta,lam):
    c=n.numel();i=torch.arange(c);rows=[]
    for row in range(c):
        values=[]
        for col in range(c):
            if row==col:value=n[col]
            elif row>col:value=-beta[row]*n[col]*(1-beta[col+1:row]).prod()
            else:value=n[col]*0
            values.append(value)
        rows.append(torch.stack(values))
    qs=torch.stack(rows)
    eta=torch.stack([beta[row]*(1-beta[:row]).prod() for row in range(c)])
    rho=torch.stack([torch.stack([1/lam[col+1:row+1].prod() if row>=col else lam[row]*0
                                 for col in range(c)]) for row in range(c)])
    nu=(1/lam).cumprod(0)
    return qs,eta,rho,nu

reports=[]
for c in (16,32,64,128):
    for curve in (0.,.02):
        n=(.8+.6*torch.rand(c,dtype=torch.float64)).requires_grad_()
        beta=torch.rand(c,dtype=torch.float64);beta[0]=0;beta[1]=1;beta[c//2]=1;beta.requires_grad_()
        raw=(.01*torch.randn(c,c,dtype=torch.float64)).requires_grad_()
        a=torch.tril(raw,-1)+torch.eye(c,dtype=torch.float64)
        v=(.1*torch.randn(c,32,dtype=torch.float64)).requires_grad_()
        h=(.1*torch.randn(c,dtype=torch.float64)).requires_grad_()
        kap=torch.tensor(curve,dtype=torch.float64,requires_grad=True)
        lam=(1+.02*torch.rand(c,dtype=torch.float64)).requires_grad_()
        sources=(n,beta,raw,v,h,kap,lam)
        qs,eta,rho,nu=common(n,beta,lam)
        gram=v@v.T;r=a*gram
        z=(qs-kap*r)*rho
        w=torch.linalg.solve(z,nu*(eta-kap*h))
        prefix_r=torch.cat((torch.zeros_like(r[:1]),r.cumsum(0)[:-1]),dim=0)
        diagonal=1/(n-kap*v.square().sum(-1))
        identity=torch.eye(c,dtype=torch.float64)
        normalized=(torch.diag(n)-kap*(r+beta[:,None]*prefix_r))*rho*diagonal[:,None]
        normalized=normalized*(1-identity)+identity
        rhs=nu*diagonal*(beta-kap*(h+beta*torch.cat((torch.zeros_like(h[:1]),h.cumsum(0)[:-1]))))
        candidate=torch.linalg.solve(normalized,rhs)
        cot=torch.randn(c,dtype=torch.float64)
        expected_grad=torch.autograd.grad(w,sources,cot,retain_graph=True)
        actual_grad=torch.autograd.grad(candidate,sources,cot,retain_graph=True)
        temp=torch.linalg.solve(normalized.T,cot)
        f=diagonal*temp
        tail=torch.zeros((),dtype=torch.float64);b=[]
        for row in reversed(range(c)):
            b.append(f[row]+tail)
            tail=(beta[row]*f[row]+tail)/lam[row]
        b=torch.stack(list(reversed(b)))
        true_b=torch.linalg.solve(z.T,cot)
        # Holding w and gauge coordinates fixed isolates the Qs/eta source contribution.
        loss=-(b.detach()*((qs*rho)@candidate.detach()-nu*eta)).sum()
        expected_n,expected_beta=torch.autograd.grad(loss,(n,beta),retain_graph=True)
        previous=torch.ones((),dtype=torch.float64);zp=[]
        for row in range(c):
            zp.append(previous)
            previous=(1-beta[row])/lam[row]*previous+n[row]*candidate[row].detach()
        zp=torch.stack(zp)
        future=torch.zeros((),dtype=torch.float64);gn=[];gb=[]
        for row in reversed(range(c)):
            gn.append((future-b[row])*candidate[row].detach())
            gb.append((b[row]-future)*zp[row]/lam[row])
            future=(beta[row]*b[row]+(1-beta[row])*future)/lam[row]
        gn=torch.stack(list(reversed(gn)));gb=torch.stack(list(reversed(gb)))
        comparisons=[(candidate,w),(b,true_b),*zip(actual_grad,expected_grad),(gn,expected_n),(gb,expected_beta)]
        errors=[float((x-y).detach().abs().max()) for x,y in comparisons]
        scaled=[error/max(1,float(y.detach().abs().max())) for error,(_,y) in zip(errors,comparisons)]
        assert max(scaled)<1e-12,(c,curve,errors,scaled)
        reports.append(dict(c=c,curvature=curve,max_scaled_error=max(scaled),max_abs=errors))
out=dict(status='MASS_PRECONDITIONER_FORWARD_ALL7_VJP_AND_SCALAR_QS_VJP_PASS',rows=reports,
         scope='Explicit untimed CPUFP64, independent dense systems; beta0/1 andc0 derivatives retained. No GPU/BF16/latency claim.')
(Path(__file__).parent/'algebra.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
